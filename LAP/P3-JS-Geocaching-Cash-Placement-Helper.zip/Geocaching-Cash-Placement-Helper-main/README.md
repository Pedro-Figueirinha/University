# Geocaching-Cash-Placement-Helper
This is the 3rd Project of the course LAP, This project consists in the development of a web application to help the user find good locations to place new cache.
