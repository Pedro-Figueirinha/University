/*     New Caches

Aluno 1: 60971 Guilherme Abrantes <-- mandatory to fill
Aluno 2: 61893 Pedro Figueirinha <-- mandatory to fill

Comment:
Para implementar a funcionalidade 6 nos criamos um conjunto de cordenadas aleatorias e
verificamos se alguma cache original esta perto para conseguir criar,
para parar metemos que o numero de tentativas falhadas sao maiores que 1000

The file "newCaches.js" must include, in the first lines,
an opening comment containing: the name and number of the two students who
developd the project; indication of which parts of the work
made and which were not made; possibly alerts to some aspects of the
implementation that may be less obvious to the teacher.

0123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789

HTML DOM documentation: https://www.w3schools.com/js/js_htmldom.asp
Leaflet documentation: https://leafletjs.com/reference.html
*/



/* GLOBAL CONSTANTS */

const MAP_INITIAL_CENTRE =
	[38.661,-9.2044];  // FCT coordinates
const MAP_INITIAL_ZOOM =
	14
const MAP_ID =
	"mapid";
const MAP_ATTRIBUTION =
	'Map data &copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> '
	+ 'contributors, Imagery © <a href="https://www.mapbox.com/">Mapbox</a>';
const MAP_URL =
	'https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token='
	+ 'pk.eyJ1IjoibWFwYm94IiwiYSI6ImNpejY4NXVycTA2emYycXBndHRqcmZ3N3gifQ.rJcFIG214AriISLbB6B5aw'
const MAP_ERROR =
	"https://upload.wikimedia.org/wikipedia/commons/e/e0/SNice.svg";
const MAP_LAYERS =
	["streets-v11", "outdoors-v11", "light-v10", "dark-v10", "satellite-v9",
		"satellite-streets-v11", "navigation-day-v1", "navigation-night-v1"]
//const RESOURCES_DIR =
//	"http//ctp.di.fct.unl.pt/lei/lap/projs/proj2122-3/resources/";
const RESOURCES_DIR =
 	"resources/";
const CACHE_KINDS = ["CITO", "Earthcache", "Event",
	"Letterbox", "Mega", "Multi", "Mystery", "Other",
	"Traditional", "Virtual", "Webcam", "Wherigo"];
const CACHE_RADIUS =
	161	// meters
const CACHES_FILE_NAME =
	"caches.xml";
const STATUS_ENABLED =
	"E"


/* GLOBAL VARIABLES */

let map = null;
/* USEFUL FUNCTIONS */

// Capitalize the first letter of a string.
function capitalize(str)
{
	return str.length > 0
			? str[0].toUpperCase() + str.slice(1)
			: str;
}

// Distance in km between to pairs of coordinates over the earth's surface.
// https://en.wikipedia.org/wiki/Haversine_formula
function haversine(lat1, lon1, lat2, lon2)
{
    function toRad(deg) { return deg * 3.1415926535898 / 180.0; }
    let dLat = toRad(lat2 - lat1), dLon = toRad (lon2 - lon1);
    let sa = Math.sin(dLat / 2.0), so = Math.sin(dLon / 2.0);
    let a = sa * sa + so * so * Math.cos(toRad(lat1)) * Math.cos(toRad(lat2));
    return 6372.8 * 2.0 * Math.asin (Math.sqrt(a));
}

function loadXMLDoc(filename)
{
	let xhttp = new XMLHttpRequest();
	xhttp.open("GET", filename, false);
	try {
		xhttp.send();
	}
	catch(err) {
		alert("Could not access the geocaching database via AJAX.\n"
			+ "Therefore, no POIs will be visible.\n");
	}
	return xhttp.responseXML;	
}

function getAllValuesByTagName(xml, name)  {
	return xml.getElementsByTagName(name);
}

function getFirstValueByTagName(xml, name)  {
	return getAllValuesByTagName(xml, name)[0].childNodes[0].nodeValue;
}

function kindIsPhysical(kind) {
	return kind === "Traditional";
}
function onLoad()
{
	map = new Map(MAP_INITIAL_CENTRE, MAP_INITIAL_ZOOM);
	map.showFCT();
	map.populate();
}
function changeCacheCoordinates(x){
	let latitude = prompt("Set latitude:", "latitude");
	let longitude = prompt("Set longitude:", "longitude");
	c = new Coordinates(38.65735,-9.227657);

	if(c.checkValid){
		
		this.latitude = 38.65735;
		this.longitude = -9.227657;
		
		if(this.kind == "Traditional"){
			alert("here");
			x.removeMarker();
			x.installMarker();}
	}		
}
function fillMapWithTraditional(){
		 map.timer = window.setInterval(spawnTraditional, 1000);
}
function spawnTraditional(){
	let minLat = 10000.00;
	let minLong = 10000.00;
	let maxLat = -10000.00;
	let maxLong = -1000.00;	 

	for(i = 0;i <map.getCaches().length;i++){
		if(map.caches[i].latitude < minLat) minLat = map.caches[i].latitude;
		if(map.caches[i].latitude > maxLat) maxLat = map.caches[i].latitude;
		if(map.caches[i].longitude < minLong) minLong = map.caches[i].longitude;
		if(map.caches[i].longitude > maxLong) maxLong = map.caches[i].longitude;
	}
	
	let latitude =  (Math.random() * (maxLat - minLat) + parseFloat(minLat)).toFixed(6);
	let longitude = (Math.random() * (maxLong - minLong) + parseFloat(minLong)).toFixed(6);
	let c1 = new Coordinates(latitude,  longitude);

	var aux = false;
	var countFails = 0;
    while(!aux){
    	if(countFails > 1000){
    		clearInterval(map.timer);
    		alert(map.cacheLimit);
    		aux = true;
    	}

        if(c1.checkValid()){
        	map.cacheLimit++;
            createTraditionalCache(c1.latitude,c1.longitude,2);
            aux = true;
        }
        else {
        	countFails++;
            latitude =  (Math.random() * (maxLat - minLat) + parseFloat(minLat)).toFixed(6);
            longitude = (Math.random() * (maxLong - minLong) + parseFloat(minLong)).toFixed(6);
            c1.latitude = latitude;
            c1.longitude = longitude;            
        }
    }
}

function countTradicionalCaches() {
	var aux = 0;
    for(var i = 0; i< map.caches.length;i++){
        if(map.caches[i].kind == "Traditional")
            aux++;
 	}
    return aux;
}
 function countMysteryCaches() {
     var aux = 0;
     for(var i = 0; i< map.caches.length;i++){
         if(map.caches[i].kind == "Mystery")
             aux++;
     }
    return aux;
}
function createTraditionalCache(lat, lng,s)
{
	let c1 = new Coordinates(lat,lng);
	if(c1.checkValid()){
	var doc = document.implementation.createDocument("", "", null);
	var cacheElem = doc.createElement("cache");
	
	var elem = doc.createElement("code");
	elem.innerHTML = "xpto";
	cacheElem.appendChild(elem);

	elem = doc.createElement("name");
	elem.innerHTML = "Traditional";
	cacheElem.appendChild(elem);
	
	if(s == 1){elem = doc.createElement("owner");
	elem.innerHTML = "xpto1";
	cacheElem.appendChild(elem);
	}
	if(s == 2){
	elem = doc.createElement("owner");
	elem.innerHTML = "xpto2";
	cacheElem.appendChild(elem);
	}
	
	elem = doc.createElement("latitude");
	elem.innerHTML = lat;
	cacheElem.appendChild(elem);
	
	elem = doc.createElement("longitude");
	elem.innerHTML = lng;
	cacheElem.appendChild(elem);

	elem = doc.createElement("altitude");
	elem.innerHTML = -32768;
	cacheElem.appendChild(elem);
	
	elem = doc.createElement("kind");
	elem.innerHTML = "Traditional";
	cacheElem.appendChild(elem);
	
	elem = doc.createElement("size");
	elem.innerHTML = "Small";
	cacheElem.appendChild(elem);
	
	elem = doc.createElement("difficulty");
	elem.innerHTML = 1.5;
	cacheElem.appendChild(elem);
	
	elem = doc.createElement("terrain");
	elem.innerHTML = 1.5;
	cacheElem.appendChild(elem);
	
	elem = doc.createElement("favorites");
	elem.innerHTML = 0;
	cacheElem.appendChild(elem);

	elem = doc.createElement("founds");
	elem.innerHTML = 0;
	cacheElem.appendChild(elem);
	
	elem = doc.createElement("not_founds");
	elem.innerHTML = 0;
	cacheElem.appendChild(elem);
	
	elem = doc.createElement("state");
	elem.innerHTML = "Setúbal";
	cacheElem.appendChild(elem);
	
	elem = doc.createElement("county");
	elem.innerHTML = "Almada";
	cacheElem.appendChild(elem);
	
	elem = doc.createElement("publish");
	elem.innerHTML = new Date();
	cacheElem.appendChild(elem);
	
	elem = doc.createElement("status");
	elem.innerHTML = "A";
	cacheElem.appendChild(elem);
	
	elem = doc.createElement("last_log");
	elem.innerHTML = new Date();
	cacheElem.appendChild(elem);

	doc.appendChild(cacheElem);

	map.addCache(new Cache(doc));
}
else
	alert("Invalid position");
}



/* POI CLASS + Cache CLASS */

class POI {
	constructor(xml) {
		this.decodeXML(xml);
	}

	decodeXML(xml) {
		if(xml === null)
			return;
		this.name = getFirstValueByTagName(xml, "name");
		this.latitude = getFirstValueByTagName(xml, "latitude");
		this.longitude = getFirstValueByTagName(xml, "longitude");
	}
	getLatitude(){
		return this.latitude;
	}
	
	installCircle(radius, color) {

		let pos = [this.latitude, this.longitude];
		let style = {color: color, fillColor: color, weight: 1, fillOpacity: 0.1};
		this.circle = L.circle(pos, radius, style);
		this.circle.bindTooltip(this.name);
		map.add(this.circle);

	}
}

class Cache extends POI {
	constructor(xml) {
		super(xml);
		this.installMarker();
	}
	
	decodeXML(xml) {
		super.decodeXML(xml);
		this.code = getFirstValueByTagName(xml, "code");
		this.owner = getFirstValueByTagName(xml, "owner");
		this.altitude = getFirstValueByTagName(xml, "altitude");

		this.kind = getFirstValueByTagName(xml, "kind");
		this.size = getFirstValueByTagName(xml, "size");
		this.difficulty = getFirstValueByTagName(xml, "difficulty");
		this.terrain = getFirstValueByTagName(xml, "terrain");


		this.favorites = getFirstValueByTagName(xml, "favorites");
		this.founds = getFirstValueByTagName(xml, "founds");
		this.not_founds = getFirstValueByTagName(xml, "not_founds");
		this.state = getFirstValueByTagName(xml, "state");
		this.county = getFirstValueByTagName(xml, "county");

		this.publish = new Date(getFirstValueByTagName(xml, "publish"));
		this.status = getFirstValueByTagName(xml, "status");
		this.last_log = new Date(getFirstValueByTagName(xml, "last_log"));
	}
	
	installMarker() {
		let pos = [this.latitude, this.longitude];
		this.marker = L.marker(pos, {icon: map.getIcon(this.kind)});
		this.marker.bindTooltip(this.name);
		this.marker.bindPopup("I'm the marker of the cache <b>" + this.name + "<br/>" + 
			"<a href=\" https://coord.info/"+ this.code +" \">View cache page." + "<br/>" + 
			"<a href=\" http://maps.google.com/maps?layer=c&cbll="+ this.latitude + "," + this.longitude +"\">Street View.</a><br/>" + 
			"<a href=\" javascript:changeCacheCoordinates(this)\">Change cache coordinates</a><br/>"+
			"<a href=\ javascript:RemoveCache(this) \>Remove cache</a><br/>");
		switch (this.owner){
			case "xpto2":
			this.installCircle(CACHE_RADIUS, "blue");
			break;
			case "xpto1":
			this.installCircle(CACHE_RADIUS, "green");
			break;
			default:
			this.installCircle(CACHE_RADIUS, "red");
		}
		map.add(this.marker);

	}
	//Changes the coordinates of an existing cache.
 
	removeMarker(){
	map.remove(this.marker);
	this.marker = null;	

	}
}

class Place extends POI {
	constructor(name, pos) {
		super(null);
		this.name = name;
		this.latitude = pos[0];
		this.longitude = pos[1];
		this.installCircle(CACHE_RADIUS, 'black');
	}
}

/* Map CLASS */

class Map {
	constructor(center, zoom) {

		this.lmap = L.map(MAP_ID).setView(center, zoom);
		this.Cordinates = new Coordinates(38.626712, -9.181137);
		
		this.cacheLimit = 0;
		this.addBaseLayers(MAP_LAYERS);
		this.icons = this.loadIcons(RESOURCES_DIR);
		this.caches = [];
		this.Timer;
		this.addClickHandler(e =>
			L.popup()
			.setLatLng(e.latlng)
			.setContent("You clicked the map at " + e.latlng.toString() + "<br/>" +
			"<a href=\" http://maps.google.com/maps?layer=c&cbll=" + e.latlng.lat + "," + e.latlng.lng + "\">Open in Street View</a><br/>" + 
			"<a href=\" javascript:createTraditionalCache("+ e.latlng.lat + "," + e.latlng.lng + "," +  1  +")\">Create cache</a><br/>"
			)
		);
	}

	populate() {
		this.caches = this.loadCaches(RESOURCES_DIR + CACHES_FILE_NAME);
	}	

	showFCT() {
		this.fct = new Place("FCT/UNL", MAP_INITIAL_CENTRE);
	}
	getIcon(kind) {
		return this.icons[kind];
	}
	getCaches() {
		return this.caches;
	}
	makeMapLayer(name, spec) {
		let urlTemplate = MAP_URL;
		let attr = MAP_ATTRIBUTION;
		let errorTileUrl = MAP_ERROR;
		let layer =
			L.tileLayer(urlTemplate, {
					minZoom: 6,
					maxZoom: 19,
					errorTileUrl: errorTileUrl,
					id: spec,
					tileSize: 512,
					zoomOffset: -1,
					attribution: attr
			});
		return layer;
	}
	addBaseLayers(specs) {
		let baseMaps = [];
		for(let i in specs)
			baseMaps[capitalize(specs[i])] =
				this.makeMapLayer(specs[i], "mapbox/" + specs[i]);
		baseMaps[capitalize(specs[0])].addTo(this.lmap);
		L.control.scale({maxWidth: 150, metric: true, imperial: false})
									.setPosition("topleft").addTo(this.lmap);
		L.control.layers(baseMaps, {}).setPosition("topleft").addTo(this.lmap);
		return baseMaps;
	}
	loadIcons(dir) {
		let icons = [];
		let iconOptions = {
			iconUrl: "??",
			shadowUrl: "??",
			iconSize: [16, 16],
			shadowSize: [16, 16],
			iconAnchor: [8, 8], // marker's location
			shadowAnchor: [8, 8],
			popupAnchor: [0, -6] // offset the determines where the popup should open
		};
		for(let i = 0 ; i < CACHE_KINDS.length ; i++) {
			iconOptions.iconUrl = dir + CACHE_KINDS[i] + ".png";
			iconOptions.shadowUrl = dir + "Alive.png";
			icons[CACHE_KINDS[i]] = L.icon(iconOptions);
			iconOptions.shadowUrl = dir + "Archived.png";
			icons[CACHE_KINDS[i] + "_archived"] = L.icon(iconOptions);
		}
		return icons;
	}
	loadCaches(filename) {
		let xmlDoc = loadXMLDoc(filename);
		let xs = getAllValuesByTagName(xmlDoc, "cache"); 
		let caches = [];
		if(xs.length === 0)
			alert("Empty cache file");
		else {
			for(let i = 0 ; i < xs.length ; i++)  // Ignore the disables caches
				if( getFirstValueByTagName(xs[i], "status") === STATUS_ENABLED )
					caches.push(new Cache(xs[i]));
		}
		return caches;
	}	
	add(marker) {
		marker.addTo(map.lmap);
	}
	addCache(c){
		this.caches.push(c);
	}
	remove(marker) {
		marker.remove();
	}
	addClickHandler(handler) {
		let m = this.lmap;
		function handler2(e) {
			return handler(e).openOn(m);
		}
		return this.lmap.on('click', handler2);
	}
}

class Coordinates {
	constructor(latitude, longitude){		
		this.latitude = latitude;
		this.longitude = longitude;
	}
	//Checks if position is valid to place a cache.
	checkValid(){	
	var aux = false;
	for(var i = 0;i <map.getCaches().length;i++){
            if ((this.hasCacheCloserThan161meters(map.caches[i]))) 
                return false;
       if(map.caches[i].owner != "xpto1" && map.caches[i].kind == "Traditional" && map.caches[i].owner != "xpto2" )     
         if (this.hasCacheWithin400meters(map.caches[i])) 
            if (!(this.hasCacheCloserThan161meters(map.caches[i]))) 
                 aux = true;           
}
	return aux;	

}
	hasCacheWithin400meters(c){		
		if((haversine(this.latitude,this.longitude,c.latitude,c.longitude)*1000) <= 400)
			return true;
		else 
			return false;
    }
    hasCacheCloserThan161meters(c){
	if((haversine(this.latitude,this.longitude,c.latitude,c.longitude)*1000) <= 161)
			return true;
		else 
			return false;
    }
}
setInterval(teste, 500);
function teste(){
	let x1 = new HTML_interactions(10);
	x1.myTimer();
}
class HTML_interactions {
constructor(updateTime){
		this.updateTime = updateTime;
	}
  myTimer() {
  	document.getElementById("statistic1").innerHTML = map.caches.length;
  	document.getElementById("statistic2").innerHTML = countTradicionalCaches();
  	document.getElementById("statistic3").innerHTML = countMysteryCaches();
}
}
