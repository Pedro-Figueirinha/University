(* Path module body *)
(* LAP (AMD 2022) *)

(* 
Student 1: Pedro Figueirinha 61893
Student 2: Guilherme Abrantes 60971
Comment:
?????????????????????????
?????????????????????????
?????????????????????????
?????????????????????????
?????????????????????????
?????????????????????????
*)

(*
0123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789
	100 columns
*)


(* COMPILATION - How Mooshak builds this module:
		ocamlc -c Path.mli Path.ml
*)



(* AUXILIARY GENERAL FUNCTIONS - you can add more *)

let rec clean l =
	match l with
	| [] -> []
	| [x] -> [x]
	| x::y::xs ->
		if x = y then clean (y::xs)
		else x::clean (y::xs)

let unique l = (* removes duplicates *)
	clean (List.sort compare l)

let lenght =
	List.length

let map =
	List.map

let filter =
	List.filter

let mem =
	List.mem

let flatMap f l =
	List.flatten (map f l)

let partition =
	List.partition

let exists =
	List.exists

let for_all =
	List.for_all

let union l1 l2 =
	clean (l1 @ l2)

let inter l1 l2 =
	filter (fun x -> mem x l2) l1

let diff l1 l2 =
	filter (fun a -> not (mem a l2)) l1



(* TYPES & CONSTANTS *)

type point = int * int
type path = point list

let _NO_PATH = []



(* SOME EXAMPLES - you can add more *)

let example1 = [
		(0,0); (0,1); (0,2);
		(1,2); (2,2); (2,1);
		(2,0); (1,0)
]

let example2 = [
		(0,0); (0,1); (0,2);
		(1,2); (2,2); (2,1);
		(2,0); (1,0); (0,0)
]

let example3 = [
		(2,2); (2,3); (2,4); (2,5);
		(3,5); (4,5); (5,5); (6,5);
		(5,4); (4,3); (3,2); (2,1);
		(1,0); (1,1); (1,2); (2,3);
		(3,4); (4,5); (5,6); (6,7)
]

let example4 = [
		(1,1); (2,1); (3,1); (4,1);
		(1,2); (2,2); (3,2); (4,2);
		(1,3); (2,3); (3,3); (4,3);
		(1,4); (2,4); (3,4); (4,4)
]

let example5 = [
        (0,4); (1,4); (2,4); (3,4); (4,4); (5,4); (6,4);                  (* line 1 *)
        (4,0); (4,1); (4,2); (4,3); (4,4); (4,5); (4,6);                  (* line 2 *)
        (0,0); (1,1); (2,2); (3,3); (4,4); (5,5); (6,6);                  (* line 3 *)
        (0,8); (1,8); (2,8); (2,9); (2,10); (1,10); (0,10); (0,9); (0,8)  (* square *)
]

let example6 = [
		(0,0); (0,1); (0,2); (0,3); (0,3); (0,4); (0,5); (0,7); (0,8)
]



(* BASIC PATH FUNCTIONS - you can add more *)

(* The first point of a list*)
let first l =
	List.hd l
;;
(* The last point of a list*)
let last p =
	first(List.rev p)
(* Is a point on a list*)	
	let rec belongs e l =
	match l with
	| [] -> false
	| x::xs ->  (e = x) || belongs e xs
	;;
(* Adjacent points? *)
let areAdjacent (x1, y1) (x2, y2) =
	abs(x2 - x1) <= 1 && abs(y2 - y1) <= 1
;;
(* Are two points the same? *)
let areSame a b =
	a = b

(* Adjacent distinct points? *)
let areAdjacentDistinct a b =
	areAdjacent a b && not (areSame a b)
;;
let slope (x1,y1) (x2,y2) =
	(y2-y1) / (x2-x1)
	;;

let move (x1,y1) (x2,y2) =
	
	(*direita e esquerda *)
	if x1 < x2 then ( x1 + 1, y1)
	else if x1 > x2 then ( x1 - 1, y1)
	
	else (*x1 = x2 *) (*cima e baixo*)
			if y1 < y2 then ( x1, y1 + 1)
			else ( x1, y1 - 1)
	;;

let rec makeSegment a b = 
	if areSame a b then  [b] else
		a:: makeSegment (move a b) b
;;

(* FUNCTION isContinuous *)

let rec isContinuous p =
	match p with
	| [] -> false
	|[x] -> true
	| x::xs -> if not (areAdjacent x (first xs)) then  false
								else isContinuous xs
	;;


(* FUNCTION intersections *)
	
let rec intersectionsX p =
	match p with
	| [] -> []
	| x::xs -> if belongs x xs then x::(intersectionsX xs)
						 else intersectionsX xs
	;;
let intersections p = unique (intersectionsX p)
;;

(* FUNCTION isSegment *)

let isSegment p =
	isContinuous p  && (lenght (intersections p) = 0)

(* FUNCTION segments *)


let rec segmentsX p interList =
    match p with
    | [] -> []
    | x :: xs -> 
            match segmentsX xs interList with
                | [] -> [[]]
                | []::_ -> [x::xs]
                | (a::l)::ls ->
			(*1*) if (belongs x interList && belongs a interList) || (not(areAdjacent x a)) then [x]::(a::l)::ls
			(*2*) else if ((areAdjacent x a && not(belongs x interList) && not(belongs a interList))) then (x::a::l)::ls (*casos normais*)												
			(*3*) else if ((areAdjacent x a && not(belongs x interList) && (belongs a interList))) then (x::a::l)::ls (*x adjacente ao a sozinho por 5*)
			(*4*) else if (x = last p && belongs x interList) then (x::a::l)::ls (*segmentos fechados*)
			(*5*) else if(belongs x interList ) then [x]::(x::a::l)::ls 
			(*6*) else ls
;;
let  segments p = segmentsX p (intersections p) ;;

(*Function interval*)
let rec getInterval p l =
	match l with
	[] -> failwith "NO_Path"
	| x :: xs -> if(x= p)then [x] else x :: getInterval p xs
	;;
	
let rec interval p a b =
	match p with
	| [] -> _NO_PATH
	| x :: xs -> if(x = a) then a :: getInterval b xs else interval xs a b
;;




(* FUNCTION best0 *)

let rec best0 pp a b =
	match pp with
	| [] -> _NO_PATH
	| [] :: _ -> _NO_PATH
	| l::ls  -> if(interval l a b = _NO_PATH) then best0 ls a b else interval l a b  

;;
 best0 (segments example5) (3,4) (4,5);;
(* FUNCTION best1 *)

let rec findNext pp ii b =
	match pp with
	| [] -> _NO_PATH
	| [] :: l ->_NO_PATH
	| (v::l)::ls -> if(belongs b (v::l) && belongs v ii) then interval (v::l) v b else findNext ls ii b
	;;
let rec best1 pp ii a b =
	match pp with
	| [] -> _NO_PATH
	| [] :: _ -> _NO_PATH
	| (v::l)::ls  ->  if not(v = a) then best1 (l::ls) ii a b else if(belongs b l) then interval l a b else
		v :: findNext ls ii b
		;;


(* FUNCTION best *)
let best pp a b =
	_NO_PATH
	;;
	(*Testes*)
makeSegment (0,0) (0,5);;
(*(int * int) list = [(0, 0); (0, 1); (0, 2); (0, 3); (0, 4); (0, 5)]*)

isContinuous example5;;
 (* bool = false *)

 intersections example5;;
(* (int * int) list = [(0, 8); (4, 4)]*)

 isSegment example5;;
 (* bool = false *)

 segments example5;;
 (*(int * int) list list =
[[(0, 4); (1, 4); (2, 4); (3, 4); (4, 4)]; [(4, 4); (5, 4); (6, 4)];
 [(4, 0); (4, 1); (4, 2); (4, 3); (4, 4)]; [(4, 4); (4, 5); (4, 6)];
 [(0, 0); (1, 1); (2, 2); (3, 3); (4, 4)]; [(4, 4); (5, 5); (6, 6)];
 [(0, 8); (1, 8); (2, 8); (2, 9); (2, 10); (1, 10); (0, 10); (0, 9); (0, 8)]]
*)
 interval example1 (0,2) (2,2);;
(*  (int * int) list = [(0, 2); (1, 2); (2, 2)]     *)

 best0 (segments example5) (3,4) (4,5);;
(*  (int * int) list = []  *)

 best1 (segments example5) (intersections example5) (3,4) (4,5);;
(*   (int * int) list = [(3, 4); (4, 4); (4, 5)]  *)

 (*best (segments example5) (intersections example5) (3,4) (4,5);; *)
(*      (int * int) list = [(3, 4); (4, 4); (4, 5)] *)
	
	
	
	
	
	
	
