public class Point {
    private final int pointNum;
    private int leftPoint;
    private int abovePoint;
    private boolean isWall;
    public Point(int pointNum, int left, int above, boolean isWall){
        this.pointNum = pointNum;
        this.leftPoint = left;
        this.abovePoint = above;
        this.isWall = isWall;
    }

    public int getPointNum(){
        return pointNum;
    }

    public int getLeftPoint(){
        return leftPoint;
    }
    public int getAbovePoint(){
        return abovePoint;
    }

    public void setIsWall(boolean isWall){
        this.isWall = isWall;
    }
    public boolean getIsWall(){
        return isWall;
    }
    public int setLeftPoint(int left){
        leftPoint = left;
        return leftPoint;
    }
    public int setAbovePoint(int above){
        abovePoint = above;
        return abovePoint;
    }
}
