import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {
    public static int columns, rows;
    @SuppressWarnings("unchecked")
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        char[] line;
        Point currentPoint;
        String input = reader.readLine();
        String[] inputs = input.split(" ");
        rows = Integer.parseInt(inputs[0]);
        columns = Integer.parseInt(inputs[1]);
        int startPointNum = Integer.parseInt(inputs[2]);
        int currPointNumber;
        new Dream(columns, rows);

        for (int r = 1; r < rows + 1; r++){
            line = reader.readLine().toCharArray();
            for (int c = 1; c < columns + 1; c++){
                currPointNumber = coordToInt(columns, r, c);
                char point = line[c - 1];
                int left = Dream.dealWithLeft(currPointNumber, point);
                int above = Dream.dealWithAbove(currPointNumber, point);
                if (point == 'O')
                    currentPoint = new Point(currPointNumber, left, above, true);
                else
                    currentPoint = new Point(currPointNumber, left, above, false);
                Dream.addPointToArray(currentPoint, currPointNumber);
            }
        }

        int xPos, yPos;
        String[] origin;
        for (int i = 0; i < startPointNum; i++){
            origin = reader.readLine().split(" ");
            xPos = Integer.parseInt(origin[0]);
            yPos = Integer.parseInt(origin[1]);
            int dream = Dream.findingHole(coordToInt(columns, xPos, yPos));
            if (dream == -1)
                System.out.println("Stuck");
            else
                System.out.println(dream);
        }
    }
    public static int coordToInt(int totalColumns, int rowNum, int colNum){
        return (rowNum - 1) * totalColumns + colNum;
    }
}