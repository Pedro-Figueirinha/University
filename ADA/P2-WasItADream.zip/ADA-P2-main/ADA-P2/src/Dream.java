import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

public class Dream {
    static int columns;
    static int rows;
    static Point[] arrayOfPoints;
    static List<Integer>[] edges;
    static int holeNodeNum;
    @SuppressWarnings("unchecked")
    public Dream(int columns, int rows){
        Dream.columns = columns;
        Dream.rows = rows;

        edges = new LinkedList[rows * columns + 1];
        arrayOfPoints = new Point[rows * columns + 1];
    }

    public static void addPointToArray (Point point, int index){
        arrayOfPoints[index] = point;
    }

    public static int dealWithLeft(int currPointNumber, char point){
        int mostLeft;
        Point leftPoint;
        switch (point){
            case '.':
                if (currPointNumber % columns == 1)
                    return currPointNumber;
                else {
                    if (arrayOfPoints[currPointNumber - 1].getIsWall())
                        return currPointNumber;
                    else
                    if (currPointNumber % columns == 0){
                        addEdge(currPointNumber, arrayOfPoints[currPointNumber - 1].getLeftPoint());
                    }
                    return arrayOfPoints[currPointNumber - 1].getLeftPoint();
                }
            case 'O':
                if (currPointNumber == 1)
                    return -1;
                else if (!arrayOfPoints[currPointNumber - 1].getIsWall() && currPointNumber % columns != 1){
                    leftPoint = arrayOfPoints[currPointNumber - 1];
                    mostLeft = arrayOfPoints[leftPoint.getLeftPoint()].getPointNum();
                    if (mostLeft == holeNodeNum)
                        addEdge(leftPoint.getPointNum(), holeNodeNum);
                    else {
                        if (mostLeft % columns == 1 && mostLeft != leftPoint.getPointNum())
                            addEdge(mostLeft, leftPoint.getPointNum());
                        else
                            addBidirectionalEdges(mostLeft, leftPoint.getPointNum());
                    }
                    return -1;
                }
                else
                    return -1;

            case 'H':
                holeNodeNum = currPointNumber;
                if (currPointNumber == 1){
                    return currPointNumber;
                }
                else if (!arrayOfPoints[currPointNumber - 1].getIsWall() && currPointNumber % columns != 1){
                    leftPoint = arrayOfPoints[currPointNumber - 1];
                    mostLeft = arrayOfPoints[leftPoint.getLeftPoint()].getPointNum();
                    addEdge(mostLeft, holeNodeNum);
                    return currPointNumber;
                }
                else
                    return currPointNumber;
        }
        return 0;
    }

    public static int dealWithAbove(int currPointNumber, char point){
        int mostAbove;
        Point abovePoint;
        switch (point){
            case '.':
                if (currPointNumber <= columns)
                    return currPointNumber;
                else {
                    if (arrayOfPoints[currPointNumber - columns].getIsWall())
                        return currPointNumber;
                    else
                        return arrayOfPoints[currPointNumber - columns].getAbovePoint();
                }
            case 'O':
                if (currPointNumber <= columns)
                    return -1;
                else if (!arrayOfPoints[currPointNumber - columns].getIsWall()){
                    abovePoint = arrayOfPoints[currPointNumber - columns];
                    mostAbove = arrayOfPoints[abovePoint.getAbovePoint()].getPointNum();
                    if (mostAbove == holeNodeNum){
                        addEdge(abovePoint.getPointNum(), holeNodeNum);
                    }
                    else {
                        if (mostAbove < columns && mostAbove != abovePoint.getPointNum())
                            addEdge(mostAbove, abovePoint.getPointNum());
                        else
                            addBidirectionalEdges(mostAbove, abovePoint.getPointNum());
                    }
                    return -1;
                }
                else
                    return -1;
            case 'H':
                holeNodeNum = currPointNumber;
                if (currPointNumber <= columns)
                    return currPointNumber;
                else if (!arrayOfPoints[currPointNumber - columns].getIsWall()){
                    abovePoint = arrayOfPoints[currPointNumber - columns];
                    mostAbove = arrayOfPoints[abovePoint.getAbovePoint()].getPointNum();
                    addEdge(mostAbove, holeNodeNum);
                    return currPointNumber;
                }
                else
                    return currPointNumber;
        }
        return 0;
    }

    private static void addBidirectionalEdges(int firstPoint, int lastPoint){
        //firstPoint -> lastPoint
        if (firstPoint != lastPoint)
            addEdge(firstPoint, lastPoint);
        if (arrayOfPoints[firstPoint].getPointNum() > columns)
            //lastPoint -> firstPoint
            addEdge(lastPoint, firstPoint);
    }
    private static boolean nodeExists(int nodeNum){
        return edges[nodeNum] != null;
    }

    private static void addEdge(int node, int adj){
        if (!nodeExists(node)){
            edges[node] = new LinkedList<>();
        }
        edges[node].add(adj);
    }

    public static int findingHole(int origin){
        Queue<Integer> currentQueue = new LinkedList<>();
        Queue<Integer> nextQueue = new LinkedList<>();
        boolean[] processed = new boolean[edges.length];
        boolean[] seen = new boolean[edges.length];
        int moveCounter = 0;
        int curr = origin;
        if (origin == holeNodeNum){
            return 0;
        }
        int left;
        int above;
        int right;
        int bottom;
        currentQueue.add(curr);
        do{
            do{
                curr = currentQueue.remove();
                left = arrayOfPoints[curr].getLeftPoint();
                above = arrayOfPoints[curr].getAbovePoint();
                if(left == holeNodeNum || above == holeNodeNum) {
                    return ++moveCounter;
                }
                if (left % columns != 1 && left != curr && !seen[left]){ //is not in first column and is != curr
                    nextQueue.add(left);
                }
                if (edges[left] != null && !processed[left]){
                    Iterator<Integer> adjIterator = edges[left].iterator();
                    while (adjIterator.hasNext()){
                        int adjacente = adjIterator.next();
                        if (Math.abs(adjacente - left ) < columns && !seen[adjacente] && adjacente != curr){
                            if (adjacente == holeNodeNum) {
                                return ++moveCounter;
                            }
                            right = adjacente;
                            nextQueue.add(right);
                            seen[right] = true;
                        }
                    }
                }

                if (arrayOfPoints[above].getPointNum() > columns && above != curr && !seen[above]){
                    nextQueue.add(above);
                }
                if (edges[above] != null && !processed[above]){
                    Iterator<Integer> adjIterator = edges[above].iterator();
                    while (adjIterator.hasNext()){
                        int adjacente = adjIterator.next();
                        if (adjacente % columns == above % columns && !seen[adjacente] && adjacente != curr){
                            if (adjacente == holeNodeNum) {
                                return ++moveCounter;
                            }
                            bottom = adjacente;
                            nextQueue.add(bottom);
                            seen[bottom] = true;
                        }
                    }
                }
                seen[curr] = true;
                processed[curr] = true;
            }while (!currentQueue.isEmpty());
            moveCounter++;
            Queue<Integer> temp = nextQueue;
            nextQueue = currentQueue;
            currentQueue = temp;
        }while (!currentQueue.isEmpty());

        return -1;
    }

}
