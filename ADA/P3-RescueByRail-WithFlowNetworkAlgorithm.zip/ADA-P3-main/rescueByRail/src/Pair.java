public class Pair {
    private final int nodeNum;
    private final int capacity;
    public Pair(int nodeNum, int capacity){
        this.nodeNum = nodeNum;
        this.capacity = capacity;
    }

    public int getNodeNum() {
        return nodeNum;
    }

    public int getCapacity() {
        return capacity;
    }
}
