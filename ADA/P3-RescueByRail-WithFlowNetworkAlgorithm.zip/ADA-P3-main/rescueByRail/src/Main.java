import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {
    public static void main(String[] args) throws IOException{

        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String[] inputs = reader.readLine().split(" ");

        int numRegions = Integer.parseInt(inputs[0]);
        int numDirectLinks = Integer.parseInt(inputs[1]);
        int finalRegion;
        int numNodes = 2*numRegions + 2;

        maxFlow flow = new maxFlow(numNodes);

        for (int r = 2; r <= numNodes - 1; r+=2){
            inputs = reader.readLine().split(" ");
            flow.createGraph(inputs, r);
        }
        for (int l = numRegions + 1; l <= numDirectLinks + numRegions; l++){
            inputs = reader.readLine().split(" ");
            flow.createGraphEdges(inputs);
        }
        finalRegion = Integer.parseInt(reader.readLine());
        int finalRegionIdx = finalRegion * 2;
        int result = flow.edmondsKarp(finalRegionIdx, 1);
        System.out.println(result);
    }
}