import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
public class maxFlow {
    private List<Pair>[] myGraph;
    private int[] capacities;
    private int[][] adjMatrix;
    @SuppressWarnings("unchecked")
    public maxFlow(int numNodes){
        myGraph = new LinkedList[numNodes];
        capacities = new int[numNodes];
        adjMatrix = new int[numNodes][numNodes];
        addEdge(myGraph,0, 1, Integer.MAX_VALUE);
        capacities[0] = Integer.MAX_VALUE;
        capacities[1] = Integer.MAX_VALUE;
        adjMatrix[0][1] = 1;
    }
    public void createGraph(String[] inputs, int r){
        int populationSize = Integer.parseInt(inputs[0]);
        addEdge(myGraph,1, r, populationSize);
        capacities[r] = populationSize;
        int capacity = Integer.parseInt(inputs[1]);
        addEdge(myGraph, r, r+1, capacity);
        capacities[r+1] = capacity;
    }
    public void createGraphEdges(String[] inputs){
        int source = Integer.parseInt(inputs[0]);
        int destination = Integer.parseInt(inputs[1]);
        int sourceIdx = 2 * source + 1;
        int destinationIdx = destination * 2;
        addEdge(myGraph,sourceIdx, destinationIdx, capacities[sourceIdx]);
        addEdge(myGraph, destinationIdx+1, sourceIdx-1, capacities[destinationIdx+1]);
    }
    private void addEdge(List<Pair>[] graph,int source, int destination, int capacity) {
        if (graph[source] == null)
            graph[source] = new LinkedList<>();
        graph[source].add(new Pair(destination, capacity));
        adjMatrix[source][destination] = 1;
    }
    private boolean edgeExists(int source, int destination){
        return adjMatrix[source][destination] == 1;
    }
    private void buildNetwork(int finalRegion){
        for (int idx = 2; idx < myGraph.length-1; idx++){
            if (myGraph[idx] != null){
                Iterator<Pair> it = myGraph[idx].iterator();
                while (it.hasNext()){
                    int currIncident = it.next().getNodeNum();
                    if (idx == finalRegion && currIncident != idx+1 && !edgeExists(currIncident, idx))
                        addEdge(myGraph, currIncident, idx, 0);
                    if (idx != finalRegion && currIncident != finalRegion && !edgeExists(currIncident, idx))
                        addEdge(myGraph, currIncident, idx, 0);
                }
            }
        }
    }
    public int edmondsKarp(int finalRegion, int source){
        int numNodes = myGraph.length;
        buildNetwork(finalRegion);
        int[][] flow = new int[numNodes][numNodes];
        int[] via = new int[numNodes];
        int flowValue = 0;
        int increment;
        while ((increment = findPath(flow, source, finalRegion, via)) != 0){
            flowValue += increment;
            int node = finalRegion;
            while (node != source){
                int origin = via[node];
                flow[origin][node] += increment;
                flow[node][origin] -= increment;
                node = origin;
            }
        }
        return flowValue;
    }
    private int findPath(int[][] flow, int source, int finalRegion, int[] via) {
        int numNodes = myGraph.length;
        Queue<Integer> waiting = new LinkedList<>();
        boolean[] found = new boolean[numNodes];
        int[] pathIncr = new int[numNodes];
        waiting.add(source);
        found[source] = true;
        via[source] = source;
        pathIncr[source] = Integer.MAX_VALUE;
        do {
            int origin = waiting.remove();
            Iterator<Pair> it = myGraph[origin].iterator();
            while (it.hasNext()){
                Pair next = it.next();
                int destin = next.getNodeNum();
                int residue = next.getCapacity() - flow[origin][destin];
                if(!found[destin] && residue > 0){
                    via[destin] = origin;
                    pathIncr[destin] = Math.min(pathIncr[origin], residue);
                    if (destin == finalRegion)
                        return  pathIncr[destin];
                    waiting.add(destin);
                    found[destin] = true;
                }
            }
        } while (!waiting.isEmpty());
        return 0;
    }
}
