public class minTimeClass {
    public final static int traverseEasyCost = 1;
    public final static int enteredWithObject = 1;
    public final static int exitedWithObject = 1;
    public final static char EASY = 'e';
    public final static char THREE_HEADED_DOG = '3';
    public final static char TROLL = 't';
    public final static char DRAGON = 'd';
    public final static char HARP = 'h';
    public final static char POTION = 'p';
    public final static char CLOAK = 'c';
    public final static int HARP_COST = 4;
    public final static int POTION_COST = 5;
    public final static int CLOAK_COST = 6;
    public static boolean HARP_EXISTS;
    public static boolean POTION_EXISTS;
    public static boolean CLOAK_EXISTS;
    public static int bestPreviousTime;
    public static int result;
    public minTimeClass(char[] input, int[][] minTime){

        HARP_EXISTS = false;
        POTION_EXISTS = false;
        CLOAK_EXISTS = false;

        for (int k = 0; k < minTime.length; k++){
            for (int m = 0; m < minTime[0].length; m++){
                minTime[k][m] = Integer.MAX_VALUE;
            }
        }
        switch (input[0]){
            case EASY -> {
                minTime[0][0] = traverseEasyCost;
            }
            case HARP -> {
                minTime [0][1] = traverseEasyCost + exitedWithObject;
                minTime[0][0] = traverseEasyCost;
                HARP_EXISTS = true;
            }
            case POTION -> {
                minTime [0][2] = traverseEasyCost + exitedWithObject;
                minTime[0][0] = traverseEasyCost;
                POTION_EXISTS = true;
            }
            case CLOAK -> {
                minTime [0][3] = traverseEasyCost + exitedWithObject;
                minTime[0][0] = traverseEasyCost;
                CLOAK_EXISTS = true;
            }
        }
        for (int k = 1; k < minTime.length; k++){
            switch (input[k]){
                case EASY -> {
                    bestPreviousTime = Math.min(Math.min(minTime[k-1][0], minTime[k-1][1]),
                            Math.min(minTime[k-1][2], minTime[k-1][3]));
                    if(input[k-1] == THREE_HEADED_DOG|| input[k-1] == TROLL || input[k-1] == DRAGON)
                        minTime[k][0] = bestPreviousTime + traverseEasyCost + enteredWithObject;
                    else
                        minTime[k][0] = bestPreviousTime + traverseEasyCost;
                    setHarpTime(minTime, k);
                    setPotionTime(minTime, k);
                    setCloakTime(minTime, k);
                }
                case HARP -> {
                    HARP_EXISTS = true;
                    setTime(minTime, input, k, 1);
                    setPotionTime(minTime, k);
                    setCloakTime(minTime, k);
                }
                case POTION -> {
                    POTION_EXISTS = true;
                    setTime(minTime, input, k, 2);
                    setHarpTime(minTime, k);
                    setCloakTime(minTime, k);
                }
                case CLOAK -> {
                    CLOAK_EXISTS = true;
                    setTime(minTime, input, k, 3);
                    setHarpTime(minTime, k);
                    setPotionTime(minTime, k);
                }
                case THREE_HEADED_DOG -> {
                    if(HARP_EXISTS)
                        minTime[k][1] = minTime[k-1][1] + HARP_COST;
                    if(POTION_EXISTS)
                        minTime[k][2] = minTime[k-1][2] + POTION_COST;
                    if(CLOAK_EXISTS)
                        minTime[k][3] = minTime[k-1][3] + CLOAK_COST;
                }
                case TROLL -> {
                    HARP_EXISTS = false;
                    if(POTION_EXISTS)
                        minTime[k][2] = minTime[k-1][2] + POTION_COST;
                    if(CLOAK_EXISTS)
                        minTime[k][3] = minTime[k-1][3] + CLOAK_COST;
                }
                case DRAGON -> {
                    POTION_EXISTS = false;
                    HARP_EXISTS = false;
                    if(CLOAK_EXISTS)
                        minTime[k][3] = minTime[k-1][3] + CLOAK_COST;
                }
            }
        }
        result = Math.min(Math.min(minTime[input.length-1][0], minTime[input.length-1][1]),
                Math.min(minTime[input.length-1][2], minTime[input.length-1][3]));
    }
    public void setTime(int[][] minTime, char[] input, int k, int item){
        bestPreviousTime = Math.min(Math.min(minTime[k-1][0], minTime[k-1][1]),
                Math.min(minTime[k-1][2], minTime[k-1][3]));
        if(input[k-1] == THREE_HEADED_DOG|| input[k-1] == TROLL || input[k-1] == DRAGON) {
            minTime[k][item] = bestPreviousTime + traverseEasyCost + enteredWithObject + exitedWithObject;
            minTime[k][0] = bestPreviousTime + traverseEasyCost + enteredWithObject;
        }
        else{
            minTime[k][item] = bestPreviousTime + traverseEasyCost + exitedWithObject;
            minTime[k][0] = bestPreviousTime + traverseEasyCost;
        }
    }
    public void setHarpTime(int[][] minTime, int k){
        if(HARP_EXISTS && minTime[k-1][1] != Integer.MAX_VALUE)
            minTime[k][1] = minTime[k-1][1] + traverseEasyCost + enteredWithObject + exitedWithObject;
    }
    public void setPotionTime(int[][] minTime, int k){
        if(POTION_EXISTS && minTime[k-1][2] != Integer.MAX_VALUE)
            minTime[k][2] = minTime[k-1][2] + traverseEasyCost + enteredWithObject + exitedWithObject;
    }
    public void setCloakTime(int[][] minTime, int k){
        if(CLOAK_EXISTS && minTime[k-1][3] != Integer.MAX_VALUE)
            minTime[k][3] = minTime[k-1][3] + traverseEasyCost + enteredWithObject + exitedWithObject;
    }
    public int getResult(){
        return result;
    }
}
