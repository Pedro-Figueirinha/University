#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
#  xFTPclient.py
#


from ctypes import sizeof


dir_path = "cdir/"


SSIZE = 2048
CHUNK = 512
msgQUIT = "QUIT"
msgDIR = "DIR"
msgGET = "GET"
msgPUT = "PUT"
msgACK = "ACK"
msgOK = "OK"
msgSTART = "START"
msgCOPYOK = "Finished copying file."
msgLISTING_END = "Finished listing."
msgCOPYFAIL = "Could not copy file."


def file_size(file_name):
    try:
        return stat(file_name).st_size
    except FileNotFoundError:
        return -1


def dir_command(clientSocket):
    clientSocket.send(msgDIR.encode())
    while (1):
        filename = clientSocket.recv(2048).decode()
        message = ""
        msg2 = message + filename
        if msg2.endswith("\r\n\r\n"):
            sys.stdout.write(filename)
            break
        else:
            sys.stdout.write(filename)

    print(msgLISTING_END)
    return


def get_command(clientSocket, skUDP, serverName, fName):
    clientSocket.send((msgGET + ";" + fName).encode())
    msg = clientSocket.recv(2048).decode()
    modMsg = msg.split(";")
    OK = modMsg[0]
    udpPort = int(modMsg[1])
    if OK == msgOK:
        skUDP.sendto(msgSTART.encode(), (serverName, udpPort))
        size = int(clientSocket.recv(2048).decode())
        file = open(dir_path + fName, 'wb')
        while size > 0:
            buf, adress = skUDP.recvfrom(CHUNK)
            file.write(buf)
            skUDP.sendto(msgACK.encode(), adress)  # (servername, port)
            size -= len(buf)
        print(msgCOPYOK)
        file.flush()
        file.close()
        return
    else:
        print(msgCOPYFAIL)
        return


def put_command(clientSocket, socketUDP, serverName, fname):
    clientSocket.send((msgPUT + ";" + fname).encode())
    msg = clientSocket.recv(2048).decode()
    modMsg = msg.split(";")
    OK = modMsg[0]
    udpPort = int(modMsg[1])
    if OK == msgOK:
        socketUDP.sendto(msgSTART.encode(), (serverName, udpPort))
        fsize = file_size(dir_path + fname)
        clientSocket.send(str(fsize).encode())
        file = open(dir_path + fname, "rb")
        while fsize > 0:
            buf = file.read(CHUNK)
            socketUDP.sendto(buf, (serverName, udpPort))
            msg, adress = socketUDP.recvfrom(2048)
            if msg.decode() != msgACK:
                break
            fsize -= len(buf)
        print(msgCOPYOK)
        return
    else:
        return


def main(args):
    if (len(args) > 2):
        serverName = args[1]
        serverPort1 = int(args[2])
    else:
        print("Invalid arguments")
        sys.exit(1)

    # create TCP socket
    clientSocket = socket(AF_INET, SOCK_STREAM)
    # open TCP connection
    clientSocket.connect((serverName, serverPort1))

    # create UDP socket
    socketUDP = socket(AF_INET, SOCK_DGRAM)

    while True:
        print("input")
        line = input("> ")
        cmdLine = line.split()
        cmd = cmdLine[0]
        cmd = cmd.upper()
        nargs = len(cmdLine)

        if cmd == msgDIR:
            if nargs != 1:
                print("Invalid arguments")
            else:
                dir_command(clientSocket)
            # ...
        elif cmd == msgGET:
            if nargs != 2:
                print("Invalid arguments")
            else:
                filename = cmdLine[1]
                get_command(clientSocket, socketUDP, serverName, filename)
            # ...

        elif cmd == msgPUT:
            if nargs != 2:
                print("Invalid arguments")
            else:
                filename = cmdLine[1]
                put_command(clientSocket, socketUDP,
                            serverName, filename)
            # ...

        elif cmd == msgQUIT:
            clientSocket.send(msgQUIT.encode())
            break

        else:
            print("Command not found")

        # ...

    socketUDP.close()
    clientSocket.close()
    print("Client shutting down")
    return 0


if __name__ == '__main__':
    import sys
    from socket import *
    from sys import stdout
    from os import stat
    import os
    sys.exit(main(sys.argv))
