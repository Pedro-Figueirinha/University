
from http.client import OK
from importlib.resources import path
from multiprocessing.connection import wait
from operator import index
from socket import *
from sys import argv, exit
from os import stat
import os

from xFTPclient import file_size
dir_path = "sdir/"
my_name = "localhost"

SSIZE = 2048
CHUNK = 512
msgQUIT = "QUIT"
msgDIR = "DIR"
msgGET = "GET"
msgPUT = "PUT"
msgACK = "ACK"
msgOK = "OK"
msgSTART = "START"
msgBAD = "BAD"
msgCOPYOK = "Finished copying file."
msgLISTING_END = "Finished listing."
msgCOPYFAIL = "Could not copy file."


def file_size(file_name):
    try:
        return stat(file_name).st_size
    except FileNotFoundError:
        return -1


def dir_command(client_sk):
    res = []
    for path in os.listdir(dir_path):
        # check if current path is a file
        if os.path.isfile(os.path.join(dir_path, path)):
            res.append(path)
    res_lenght = len(res)-1
    for f in res:
        if res.index(f) == res_lenght:
            client_sk.send((f + "\r\n").encode())
            client_sk.send(("\r\n").encode())
            break
        else:
            client_sk.send((f + "\r\n").encode())
    return


def file_exists(fName):
    for path in os.listdir(dir_path):
        if os.path.isfile(os.path.join(dir_path, path)):
            if os.path.basename(path) == fName:
                return True
    return False


def get_command(client_sk, skUDP, fName, UDPport):
    while True:
        if (file_exists(fName)):
            client_sk.send((msgOK + ";" + str(UDPport)).encode())
            msg, adress = skUDP.recvfrom(2048)  # received start
            start = msg.decode()
            if (start == msgSTART):
                fsize = file_size(dir_path + fName)
                client_sk.send(str(fsize).encode())
                file = open(dir_path + fName, "rb")
                while fsize > 0:
                    buf = file.read(CHUNK)
                    skUDP.sendto(buf, adress)
                    msg, adress = skUDP.recvfrom(2048)
                    if msg.decode() != msgACK:
                        break
                    fsize -= len(buf)
                file.flush()
                file.close()
                return
        else:
            client_sk.send((msgBAD + ";" + str(UDPport)).encode())
            return

    # ...


def put_command(client_sk, skUDP, fName, UDPport):
    while True:
        if (file_exists(fName) == False):
            client_sk.send((msgOK + ";" + str(UDPport)).encode())
            msg, adress = skUDP.recvfrom(2048)  # received start
            start = msg.decode()
            if (start == msgSTART):
                size = int(client_sk.recv(2048).decode())
                file = open(dir_path + fName, 'wb')
                while size > 0:
                    # receive file via udp
                    buf, adress = skUDP.recvfrom(CHUNK)

                    file.write(buf)
                    skUDP.sendto(msgACK.encode(), adress)
                    size -= len(buf)
                file.flush()
                file.close()
        else:
            client_sk.send((msgBAD + ";" + str(UDPport)).encode())
        return


def run_server(TCPport, UDPport):
    sk = socket(AF_INET, SOCK_STREAM)
    sk.bind(('', TCPport))
    sk.listen(5)
    skUDP = socket(AF_INET, SOCK_DGRAM)
    skUDP.bind(("", UDPport))
    print('Server is working')
    while True:  # loop to accept client connections
        print("Accepting connections")
        client_sk, add = sk.accept()
        print('-------------------------------------------')
        print('Incoming connection from', add)
        while True:  # loop to accept the client commands
            print("Accepting commands")
            msg = client_sk.recv(2048).decode()
            modMsg = msg.split(";")
            command_name = modMsg[0]
            if command_name == msgDIR:
                dir_command(client_sk)
            # ...
            elif command_name == msgGET:
                fName = modMsg[1]
                print("\ntcp\n")
                print(client_sk)
                print("\nudp\n")
                print(skUDP)
                get_command(client_sk, skUDP, fName, UDPport)
            # ...

            elif command_name == msgPUT:
                fName = modMsg[1]
                put_command(client_sk, skUDP, fName, UDPport)

            # ...

            elif command_name == msgQUIT:
                break

            else:
                print("Command not found")
            print('-------------------------------------------')


if __name__ == '__main__':
    if len(argv) != 3:
        print('wrong number of arguments')
        print("call ./program <port>")
        exit(1)

    TCPport = int(argv[1])
    UDPport = int(argv[2])
    run_server(TCPport, UDPport)
