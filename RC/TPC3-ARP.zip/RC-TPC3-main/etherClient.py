#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Nov 12 00:29:17 2022

@author: a.rijo
"""

import socket
import sys
import ethernetTools as et

# sys.argv[1]: ethernet address to send message
if len(sys.argv) < 2:
    print("[ERROR]Unexpected number of arguments")
    print("Usage: python3 simpleClient.py targetEthernetAddress (example: aa:bb:cc:dd:ee:ff)")
    exit(0)


if __name__ == "__main__":
    # creates RAW ethernet socket
    sck = socket.socket(socket.AF_PACKET, socket.SOCK_RAW,
                        socket.htons(et.ETH_P_ALL))
    # Binding ethernet interface to the socket
    sck.bind(("eth0", 0))

    # eth0 - default name of the ethernet interface in UNIX
    my_addr = et.get_self_addr(sck, 'eth0')
    # prints ethernet address in human-readable format
    print('My Ethernet address:', et.bytes_ether_addr_to_string(my_addr))
    # argv[1]: ethernet address of target device
    ip_addr = et.ip_addr_to_bytes(sys.argv[1])
    
    target_addr = et.ether_addr_to_bytes("ff:ff:ff:ff:ff:ff")
    print('Target IP address:', sys.argv[1])

    msg = "Who has this IP adress:" + sys.argv[1]

    # builds frame to send
    frame = et.build_frame(target_addr, my_addr, msg)
    sck.send(frame)

    while True:
        recv_frame = sck.recv(et.MAX_FRAME_SIZE)

        my_addr_in_frame, sender_addr, _, msg = et.extract_frame(recv_frame)
        #print("sender",et.bytes_ether_addr_to_string(sender_addr))
        #print("my_addr_frame", my_addr_in_frame)
        if (my_addr_in_frame != target_addr):
            print("\n" + "Message received: \n" + msg + " and my Ethernet adress is: " + et.bytes_ether_addr_to_string(sender_addr))
            break
    sck.close()
