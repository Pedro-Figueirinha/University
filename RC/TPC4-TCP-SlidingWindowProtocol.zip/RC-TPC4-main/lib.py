from constants import *
import socket
import time
import sys
import os
import select
from os import stat


def file_exists(dir_path, fName):
    for path in os.listdir(dir_path):
        if os.path.isfile(os.path.join(dir_path, path)):
            if os.path.basename(path) == fName:
                return True
    return False


def file_size(fname_in_sender):
    try:
        return stat(fname_in_sender).st_size
    except FileNotFoundError:
        return -1


# sends an UPLOAD datagram to the destination (hostname, port) specified
def sendUploadDatagram(socket, destinationHostname, destinationPort, filename):
    dg_type = 0
    byte1 = dg_type.to_bytes(4, 'little')
    uploadMsg = byte1 + filename.encode()
    socket.sendto(uploadMsg, (destinationHostname, destinationPort))


# sends a DATA datagram to the destination (hostname, port) specified with seqNum
# sequence number
def sendDataDatagram(socket, destinationHostname, destinationPort, seqNum, data):
    dg_type = 1
    byte1 = dg_type.to_bytes(4, 'little')
    byte2 = int(seqNum).to_bytes(4, 'little')
    bytesToSend = byte1 + byte2 + data

    socket.sendto(bytesToSend, (destinationHostname, destinationPort))


# sends a FIN datagram with seqNum sequence number to the destination(hostname, port)
# specified
def sendFinDatagram(socket, destinationHostname, destinationPort, seqNum):
    dg_type = 2
    byte1 = dg_type.to_bytes(4, 'little')
    byte2 = int(seqNum).to_bytes(4, 'little')
    finMsg = byte1 + byte2
    socket.sendto(finMsg, (destinationHostname, destinationPort))


# sends an ACK datagram with seqNum sequence number to the destination (hostname,
# port) specified
def sendAckDatagram(socket, destinationHostname, destinationPort, seqNum):
    dg_type = 3
    byte1 = dg_type.to_bytes(4, 'little')
    byte2 = int(seqNum).to_bytes(4, 'little')

    ackMsg = byte1 + byte2
    socket.sendto(ackMsg, (destinationHostname, destinationPort))

#

# TODO check select()


def recvDatagram(socket, timeOutInSeconds):

    #res = 0
    # try:
    #
    #    socket.settimeout(timeOutInSeconds)
    #    msg, addr = socket.recvfrom(CHUNK)
    #    print("\nname: " + addr[0] + " port: " + str(addr[1]))
    #    # se datagram data msg tem 3 coisas (id, seqnum, data), senao tem 2(id, seqnum)
    # except socket.timeout:
    #    res = -1
    # return res, msg, addr
    #
    res = 0
    ready = select.select([socket], [], [], timeOutInSeconds)
    if ready[0] == []:
        return -1, -1, -1
    else:
        # if data sent need CHUNK + dg_type(4bytes) + dg_seqNum(4bytes)
        msg, addr = socket.recvfrom(CHUNK + 8)

    return res, msg, addr
