from lib import *
from constants import *
import socket
import time
import sys
dir_path = "receiverDir/"
file_name = ""

if len(sys.argv) < 2:
    print("Invalid arguments")
    sys.exit(1)


if __name__ == "__main__":

    if (len(sys.argv) > 2):
        recv_port = int(sys.argv[1])
        sender_port = int(sys.argv[2])

    else:
        print("Invalid arguments")
        sys.exit(1)
    destinationSocket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    mySocket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    mySocket.bind(("localhost", recv_port))
    state = STATES.START_STATE
    seqCount = 0
    flag = 0
    while state != STATES.END_STATE:
        match state:
            case STATES.START_STATE:
                print("\n\tSTART STATE")
                while True:
                    print("\nWaiting for upload dg...")
                    res, msg, addr = recvDatagram(mySocket, TIMEOUT)
                    print("\nReceived datagram from: " +
                          str(addr[0]) + "port: " + str(addr[1]))
                    dg_type = int.from_bytes(msg[0:3], "little")
                    # first data chunk
                    print("dg_type:" + str(dg_type))
                    if dg_type == DATA_ID:
                        dg_seqNum = int.from_bytes(msg[4:7], "little")
                        if seqCount + 1 == dg_seqNum:
                            print("Writing first data chunk")
                            seqCount += 1
                            #data = msg[8:]
                            file = open(dir_path + file_name, "wb")
                            file.write(msg[8:])
                            state = STATES.TRANSFER_STATE
                            break

                    elif ((res < 0) or dg_type != UPLOAD_ID):
                        print("\nupload not received")
                        print(
                            "\nres: " + str(res) + "reply id: " + str(dg_type))
                        continue
                    elif (dg_type == UPLOAD_ID):
                        if (flag):  # ja tinha recebido means ack lost
                            #
                            print("\nupload was already received, resending ack")
                            sendAckDatagram(
                                destinationSocket, addr[0], addr[1], seqCount)
                        else:
                            print("\n first upload received")
                            flag = 1
                            file_name = msg[4:].decode()
                            file = open(dir_path + file_name,
                                        "wb")  # necessario?
                            sendAckDatagram(
                                destinationSocket, "localhost", sender_port, seqCount)

            case STATES.TRANSFER_STATE:
                print("\n\tTRANSFER STATE")
                if (len(file_name) == 0):
                    print("file_name is an empty string")
                    exit(1)

                file = open(dir_path + file_name, "wb")
                flag = 1
                while True:
                    if (flag):  # reply to first data dg
                        print(
                            "\nreply to first data dg, curr seqCount:" + str(seqCount))
                        sendAckDatagram(destinationSocket,
                                        "localhost", sender_port, seqCount)
                        flag = 0
                    print("\nwaiting for next data dg...")
                    res, msg, addr = recvDatagram(mySocket, TIMEOUT)
                    dg_type = int.from_bytes(msg[0:3], "little")
                    dg_seqNum = int.from_bytes(msg[4:7], "little")
                    print("\ndg_type: " + str(dg_type) +
                          " dg_seqnum: " + str(dg_seqNum) +
                          " seqcount: " + str(seqCount))
                    if dg_type == DATA_ID and seqCount == dg_seqNum:  # ack falhou
                        print("\ndata ack failed, resending")
                        sendAckDatagram(destinationSocket,
                                        addr[0], addr[1], seqCount)
                    elif dg_type == FIN_ID and seqCount+1 == dg_seqNum:
                        print("received fin")
                        file.close()
                        seqCount += 1
                        state = STATES.FINWAIT_STATE
                        sendAckDatagram(destinationSocket,
                                        "localhost", sender_port, seqCount)
                        break
                    elif (res < 0 or dg_type != DATA_ID):
                        # timeout ou not data ou (seqNum dif e seq - 1 dif)
                        print("error at transfer")
                        continue
                    elif dg_type == DATA_ID and seqCount + 1 == dg_seqNum:
                        print("\ngood data dg, going to write to file")
                        data = msg[8:]
                        file.write(data)
                        seqCount += 1
                        print("\n\tsending ack num:" + str(seqCount))
                        sendAckDatagram(destinationSocket,
                                        "localhost", sender_port, seqCount)
            case STATES.FINWAIT_STATE:
                print("\n\FIN STATE")
                while True:
                    res, msg, addr = recvDatagram(mySocket, TIMEOUT)

                    if (res < 0):
                        print("Fin timeout exceeded. Exiting...")
                        break
                    sendAckDatagram(destinationSocket,
                                    "localhost", sender_port, seqCount)
                state = STATES.END_STATE
            case STATES.END_STATE:
                mySocket.close()
                destinationSocket.close()
                exit(0)
