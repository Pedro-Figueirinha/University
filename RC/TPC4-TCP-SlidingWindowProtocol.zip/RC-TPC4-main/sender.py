from constants import *
from stat import *
import os
from lib import *
import socket
import time
import sys

dir_path = "senderDir/"

if len(sys.argv) < 6:
    print("Invalid arguments")
    sys.exit(1)


if __name__ == "__main__":
    sender_port = int(sys.argv[1])
    recv_hostname = sys.argv[2]
    recv_port = int(sys.argv[3])
    name_in_recv = sys.argv[4]
    fname_in_sender = sys.argv[5]

    destinationSocket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    mySocket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    mySocket.bind(("", sender_port))
    state = STATES.START_STATE
    seqCount = 0

    while state != STATES.END_STATE:
        match state:
            case STATES.START_STATE:
                print("\n\tSTART STATE")

                while True:
                    print("\nSending upload dg to: " +
                          recv_hostname + " Port: " + str(recv_port))
                    sendUploadDatagram(
                        destinationSocket, recv_hostname, recv_port, name_in_recv)
                    print("Sent upload dg")
                    res, msg, addr = recvDatagram(mySocket, TIMEOUT)
                    dg_type = int.from_bytes(msg[0:3], "little")
                    dg_seqNum = int.from_bytes(msg[4:7], "little")
                    if ((res < 0) or (dg_type != ACK_ID) or (seqCount != dg_seqNum)):
                        print("\nack of upload not received")
                        continue
                    elif (dg_type == ACK_ID) and (seqCount == dg_seqNum):
                        print("\nack of upload received: SUCCESS")
                        seqCount += 1
                        state = STATES.TRANSFER_STATE
                        break
            case STATES.TRANSFER_STATE:
                print("\n\tTRANSFER STATE")
                flag = 1
                file = open(dir_path + fname_in_sender, "rb")
                fsize = file_size(dir_path + fname_in_sender)
                while fsize > 0:
                    if (flag):
                        print("\nReading CHUNK from file")
                        data = file.read(CHUNK)

                    sendDataDatagram(destinationSocket,
                                     recv_hostname, recv_port, seqCount, data)
                    print("\n\tSent data dg num: " + str(seqCount) +
                          "\nWaiting for ack num: " + str(seqCount))

                    res, msg, addr = recvDatagram(mySocket, TIMEOUT)
                    dg_type = int.from_bytes(msg[0:3], "little")
                    dg_seqNum = int.from_bytes(msg[4:7], "little")
                    if (res < 0 or dg_type != ACK_ID or seqCount != dg_seqNum):
                        print("\nack of data not received")
                        flag = 0
                        continue
                    # lastchunk
                    elif dg_type == ACK_ID and seqCount == seqCount and fsize <= CHUNK:
                        print("\nreceiver got lastchunk")
                        seqCount += 1
                        file.close()
                        state = STATES.FINWAIT_STATE
                        break
                    elif dg_type == ACK_ID and seqCount == dg_seqNum and fsize > CHUNK:
                        print("\nReceived data chunk")
                        seqCount += 1
                        flag = 1
                        fsize -= len(data)  # str(data)
            case STATES.FINWAIT_STATE:
                print("\n\tFINWAIT_STATE")
                while True:
                    print("\nSending fin dg to: " +
                          recv_hostname + " Port: " + str(recv_port))
                    sendFinDatagram(destinationSocket,
                                    recv_hostname, recv_port, seqCount)
                    print("Sent fin dg")
                    res, msg, addr = recvDatagram(mySocket, TIMEOUT)
                    dg_type = int.from_bytes(msg[0:3], "little")
                    dg_seqNum = int.from_bytes(msg[4:7], "little")
                    if (res < 0 or dg_type != ACK_ID or seqCount != dg_seqNum):
                        print("\nack of fin not received")
                        print(
                            "\nres: " + str(res) + " reply id: " + str(dg_type) + "\tseqCount = seq recv?: " + seqCount == dg_seqNum)
                        continue
                    elif dg_type == ACK_ID and seqCount == dg_seqNum:
                        print("end state")
                        state = STATES.END_STATE
                        break
            case STATES.END_STATE:
                print("\n\tEND_STATE")
                mySocket.close()
                destinationSocket.close()
                exit(0)
