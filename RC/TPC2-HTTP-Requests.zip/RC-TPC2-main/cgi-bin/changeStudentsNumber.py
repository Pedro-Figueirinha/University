#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import sqlite3
import cgi
import sys
import codecs

sys.stdout = codecs.getwriter("utf-8")(sys.stdout.detach())
print("""Content-type:text/html\n\n
<!DOCTYPE html>
<head>
    <title> Change Course number of students</title>
</head>
<body> """)

form = cgi.FieldStorage()

id_num = str(form["code"].value)
students_number = str(form["students_enrolled"].value)

db_connection = sqlite3.connect('Courses.db')
cursor = db_connection.cursor()

try:
    cursor.execute('UPDATE Courses SET students_enrolled = ? WHERE id = ?;',
                   (int(students_number), int(id_num)))
except sqlite3.Error as er:
    print('Error in UPDATE: ', er)
db_connection.commit()
rowcount = cursor.rowcount
db_connection.close()

if (rowcount == 0):
    print('<h2> Course ' + id_num + ' does not exist. </h2> <p>')
    print("""  <p> <a href="http://localhost:5555/index.html" > Return to main page. </a> </p>
</body>
</html>""")
else:
    print('<h2> Course ' + id_num +
          ': number of students enrolled was set to ' + students_number + '</h2> <p>')
    print("""  <p> <a href="http://localhost:5555/index.html" > Return to main page. </a> </p>
</body>
</html>""")
