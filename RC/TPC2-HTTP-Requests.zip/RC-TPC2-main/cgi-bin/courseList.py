#!/usr/bin/env python
# -*- coding: UTF-8 -*-
#!
from itertools import count
import sqlite3
import sys
import codecs

sys.stdout = codecs.getwriter("utf-8")(sys.stdout.detach())

print("""Content-type:text/html\n\n
<!DOCTYPE html>
<head>
    <title> Course List </title>
</head>
<body>
    
    <h1> Course List </h1>
	<h2> Courses </h2> """)

db_connection = sqlite3.connect('Courses.db')
cursor = db_connection.cursor()
try:
    cursor.execute("SELECT * FROM Courses;")
    linhas = cursor.fetchall()
except sqlite3.Error as er:
    print('Error in SELECT: ', er)

print('<ul>')
student_count = 0
for linha in linhas:
    print('<li>' + str(linha[0]) + ' ' + linha[1] + ' '
          + str(linha[2]), '</li>')
    student_count += int(linha[2])

print('</ul>')
print('<h4> Number of courses = ' + str(len(linhas)) +
      " Total number of students = " + str(student_count) +
      " Average number of students = " + str(student_count / len(linhas)), '</h4')
print("""</body> </html>""")

db_connection.commit()
db_connection.close()
