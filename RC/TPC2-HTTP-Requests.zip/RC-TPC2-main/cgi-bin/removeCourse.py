#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import sqlite3
import cgi
import sys
import codecs

sys.stdout = codecs.getwriter("utf-8")(sys.stdout.detach())
print("""Content-type:text/html\n\n
<!DOCTYPE html>
<head>
    <title> Remove a Course </title>
</head>
<body> """)

form = cgi.FieldStorage()

id_num = str(form["code"].value)

db_connection = sqlite3.connect('Courses.db')
cursor = db_connection.cursor()

try:
    cursor.execute('DELETE FROM Courses WHERE id = ?;',
                   (int(id_num),))
except sqlite3.Error as er:
    print('Error in DELETE: ', er)
db_connection.commit()
rowcount = cursor.rowcount
db_connection.close()

if (rowcount == 0):
    print('<h2> Course ' + id_num + ' does not exist. </h2> <p>')
    print("""  <p> <a href="http://localhost:5555/index.html" > Return to main page. </a> </p>
</body>
</html>""")
else:
    print('<h2> Course ' + id_num + ' was removed. </h2> <p>')
    print("""  <p> <a href="http://localhost:5555/index.html" > Return to main page. </a> </p>
</body>
</html>""")
