
const listBtn = document.getElementById('listBtn');
listBtn.addEventListener('click', function() {
    console.log("ckicked");
    const xhttp = new XMLHttpRequest();
    var div = document.getElementById("demo");
    xhttp.onreadystatechange = function(){
        if(xhttp.readyState == 4){
            if(xhttp.status == 200){
                div.innerHTML = xhttp.responseText;
            }
        }
    }
    xhttp.open("GET","http://localhost:5555/cgi-bin/courseList.py", true);
    xhttp.send();
})




