#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Oct 18 15:03:34 2022

@author: mac
"""
import sqlite3
from sqlite3 import Error


def create_connection(db_file):
    """ create a database connection to the SQLite database
        specified by db_file
    :param db_file: database file
    :return: Connection object or None
    """
    conn = None
    try:
        conn = sqlite3.connect(db_file)
        return conn
    except Error as e:
        print("hello")
        print(e)

    return conn


def create_table(conn, create_table_sql):
    """ create a table from the create_table_sql statement
    :param conn: Connection object
    :param create_table_sql: a CREATE TABLE statement
    :return:
    """
    try:
        c = conn.cursor()
        c.execute(create_table_sql)
    except Error as e:
        print(e)

#


def insertIntoTable(conn, id_num, course_name, students_enrolled):
    try:
        cursor = conn.cursor()
        print("Connected to SQLite")

        sqlite_insert_with_param = """INSERT INTO Courses
                          (id,course_name, students_enrolled) 
                          VALUES (?, ?, ?);"""

        data_tuple = (id_num, course_name, students_enrolled)
        cursor.execute(sqlite_insert_with_param, data_tuple)
        conn.commit()
        print("Python Variables inserted successfully into Course table")

    except sqlite3.Error as error:
        print("Failed to insert Python variable into sqlite table", error)

#


def main():
    database = r"Courses.db"  # db name with path

    sql_create_courses_table = """ CREATE TABLE IF NOT EXISTS Courses (
                                        id integer PRIMARY KEY,
                                        course_name text NOT NULL,
                                        students_enrolled text NOT NULL
                                    ); """

    # create a database connection
    conn = create_connection(database)

    # create tables
    if conn is not None:
        # create employees table
        create_table(conn, sql_create_courses_table)
        # insert values into database
        insertIntoTable(conn, 1, 'POO', '10')
        insertIntoTable(conn, 2, 'RC', '2')
        insertIntoTable(conn, 3, 'LAP', '5')
        insertIntoTable(conn, 4, 'TC', '9')
        conn.close()

    else:
        print("Error! cannot create the database connection.")


if __name__ == '__main__':
    main()
