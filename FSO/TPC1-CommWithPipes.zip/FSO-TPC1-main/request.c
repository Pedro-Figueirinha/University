/**
 * Created by the FSO 2022/23 team.
 */

#include <string.h>
#include <unistd.h>

#include "request.h"

int send_request(int inbox, const request *req) {
    // TODO: allocate buffer to store the serialization of the request to be sent to the server

    // TODO: fill the buffer with the request's data

    // TODO: write the request in the server's inbox

    return 0;
}


int recv_request(int inbox, request *req) {
    // TODO: read the request from the inbox

    // TODO: fill req with the content's read from the inbox

    return 0;
}
