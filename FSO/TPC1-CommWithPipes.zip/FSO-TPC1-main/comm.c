/**
 * Created by the FSO 2022/23 team.
 */

#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <stdlib.h>
#include <stdio.h>
#include "comm.h"


int create_inbox(const char* inbox_name) {
  int erro;
  if(access(inbox_name, F_OK) != 0){ //file does not exist
    erro = mkfifo(inbox_name, 0666);
  }
  return erro;
}

int accept(const char* inbox_name) {
    int fd = open(inbox_name, O_RDONLY);
    return fd;  
}

int connect(const char* inbox_name) {
  int fd = open(inbox_name, O_WRONLY);
  return fd;
}
