/**
 * Created by the FSO 2022/23 team.
 */
#ifndef FSO_REQUEST_H
#define FSO_REQUEST_H

/**
 * Struct that defines a request
 */
typedef struct {
    char reply_to[1024];
    char file_name[1024];
} request;

/**
 * Send a request to an inbox
 * @param inbox The inbox's descriptor
 * @param req The request
 * @return 0, if the operation executed successfully, -1 otherwise.
 * In error situations, the error code is assigned to the global errno variable.
 */
int send_request(int inbox, const request* req);

/**
 * Receive a request from an inbox
 * @param inbox The inbox's descriptor
 * @param req The request to fill (must be pre-allocated)
 * @return 0, if the operation executed successfully, -1 otherwise.
 * In error situations, the error code is assigned to the global errno variable.
 */
int recv_request(int inbox, request *req);

#endif //FSO_REQUEST_H
