/**
 * Created by the FSO 2022/23 team.
 */

#ifndef FSO_COMM_H
#define FSO_COMM_H

/**
 * Location of the server's inbox by default
 */
static const char* default_server_inbox_name = "/tmp/fso_server";

/**
 * Create an inbox to receive messages. If the inbox already exists. It deletes it and creates a new one.
 * @param inbox_name Name of the inbox
 * @return 0, if the operation executed successfully, -1 otherwise.
 * In error situations, the error code is assigned to the global errno variable.
 */
int create_inbox(const char* inbox_name);

/**
 * Accept connections on a given inbox, in order to read data sent to such inbox.
 * @param inbox_name The inbox's name
 * @return 0, if the operation executed successfully, -1 otherwise.
 * In error situations, the error code is assigned to the global errno variable.
 */
int accept(const char* inbox_name);

/**
 * Connect to a given inbox, in order to be able to write messages to such inbox,
 * @param inbox_name The inbox's name
 * @return 0, if the operation executed successfully, -1 otherwise.
 * In error situations, the error code is assigned to the global errno variable.
 */
int connect(const char* inbox_name);

#endif // FSO_COMM_H