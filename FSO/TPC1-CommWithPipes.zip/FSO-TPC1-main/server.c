/**
 * Created by the FSO 2022/23 team.
 */


#include <stdio.h>
#include <errno.h>
#include <unistd.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>

#include "comm.h"
#include "request.h"

void handle_request(const request* req);

int main(int argc, char* argv[]) {

    if (argc > 2) {
        printf ("usage: %s [inbox_name]", argv[0]);
        return 1;
    }

    // create inbox
    const char* inbox_name = argc == 1 ? default_server_inbox_name: argv[1];
    int inbox_ok; // TODO: create client inbox
    if (inbox_ok == -1) {
        perror("create inbox");
        return errno;
    }

    printf ("Created inbox.\n");

    while (1) {

        // Accept client connections
        int inbox; // TODO: accept client connection
        if (inbox == -1) {
            perror("accept");
            continue;
        }
        printf ("Accepted new connection.\n");

        // Receive request
        request req;
        int request_ok; // TODO: receive request
        if (request_ok == -1) {
            perror("Receive request");
            continue;
        }
        printf("New request: send file %s.\n", req.file_name);

        // Handle request
        handle_request(&req);
    }
}


void handle_request(const request* req) {
    // TODO: handle the request in a new execution flow: process or thread
}


