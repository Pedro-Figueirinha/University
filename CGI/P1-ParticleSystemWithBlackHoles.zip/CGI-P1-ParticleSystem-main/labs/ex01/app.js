import { buildProgramFromSources, loadShadersFromURLS, loadShadersFromScripts, setupWebGL } from "../../libs/utils.js";
import {vec2, flatten} from "../../libs/MV.js";

/** @type {WebGLRenderingContext} */
var gl;
var program;


function setup(shaders){
    //Setup
    const canvas = document.getElementById("gl-canvas");
    gl = setupWebGL(canvas);
    //create program
    program = buildProgramFromSources(gl, shaders["shader.vert"], shaders["shader.frag"]);
    //created array with vertices of triangle
    const vertices = [ vec2(-0.5,-0.5), vec2(0.5,-0.5), vec2(0,0.5) ];

    /*A buffer is a contiguous block of memory in the GPU
        that can be accessed very quickly by shader programs
        executing on the GPU.
        Buffer objects store the data that shader programs
        need for rendering.
        Contents are 1 dim arrays    
    */
    //create buffer
    const aBuffer = gl.createBuffer();
    //activate buffer
    gl.bindBuffer(gl.ARRAY_BUFFER, aBuffer);
    //buffer able to receive data as vertices
    //gl.ARRAY_BUFFER is now binded
    //gl.STATIC_DRAW -> static and not dinamic bc we don't want to change its values.
    gl.bufferData(gl.ARRAY_BUFFER, flatten(vertices), gl.STATIC_DRAW);

    //got index of attribute type, which is of type vPosition
    const vPosition = gl.getAttribLocation(program, "vPosition");
    gl.vertexAttribPointer(vPosition,2, gl.FLOAT, false, 0,0);
    gl.enableVertexAttribArray(vPosition);
    //Setup the viewport
    gl.viewport(0,0, canvas.width, canvas.height );

    //Setup the background
    gl.clearColor(0.0,0.0,0.0,1.0);
    //Call animate for the first time
    animate();
}


function animate(){
    window.requestAnimationFrame(animate);

    //Drawing code
    gl.clear(gl.COLOR_BUFFER_BIT);

    gl.useProgram(program);
    gl.drawArrays(gl.TRIANGLES, 0, 3);
}
loadShadersFromURLS(["shader.vert", "shader.frag"]).then(shaders => setup(shaders));
//setup(loadShadersFromScripts(["shader.vert", "shader.frag"]));