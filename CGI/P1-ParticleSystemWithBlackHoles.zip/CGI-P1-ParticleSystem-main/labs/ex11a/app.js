import { buildProgramFromSources, loadShadersFromURLS, loadShadersFromScripts, setupWebGL } from "../../libs/utils.js";
import {vec2, flatten} from "../../libs/MV.js";

/** @type {WebGLRenderingContext} */
var gl;
var program;
const N_VERTICES = 1000;

function setup(shaders){
    //Setup
    const canvas = document.getElementById("gl-canvas");
    gl = setupWebGL(canvas);
    //create program
    program = buildProgramFromSources(gl, shaders["shader.vert"], shaders["shader.frag"]);
    //created array with vertices of triangle
    const vertices = [ ];

    for(let i = 0; i < N_VERTICES; i++){
        vertices.push(vec2(0.0,0.0)); // Coordinates for 1st polygon

        let angle = 2 * Math.PI * i /N_VERTICES;
        //0.8 = radius
        vertices.push(vec2(0.8 * Math.cos(angle), 0.8 * Math.sin(angle))); // Coordinates for 2nd polygin
    }
    

    /*A buffer is a contiguous block of memory in the GPU
        that can be accessed very quickly by shader programs
        executing on the GPU.
        Buffer objects store the data that shader programs
        need for rendering.
        Contents are 1 dim arrays    
    */
    //create buffer
    const aBuffer = gl.createBuffer();
    //activate buffer
    gl.bindBuffer(gl.ARRAY_BUFFER, aBuffer);
    //buffer able to receive data as vertices
    //gl.ARRAY_BUFFER is now binded
    //gl.STATIC_DRAW -> static and not dinamic bc we don't want to change its values.
    gl.bufferData(gl.ARRAY_BUFFER, flatten(vertices), gl.STATIC_DRAW);

    //got index of attribute type, which is of type vPosition
    const vPosition1 = gl.getAttribLocation(program, "vPosition1");
    gl.vertexAttribPointer(vPosition1,2, gl.FLOAT, false, 16,0);
    gl.enableVertexAttribArray(vPosition1);

    const vPosition2 = gl.getAttribLocation(program, "vPosition2");
    gl.vertexAttribPointer(vPosition2,2, gl.FLOAT, false, 16,8);
    gl.enableVertexAttribArray(vPosition2);
    //Setup the viewport
    gl.viewport(0,0, canvas.width, canvas.height );

    //Setup the background
    gl.clearColor(0.0,0.0,0.0,1.0);

    window.requestAnimationFrame(animate);

    function getRandomPosition(){
        let x = Math.random() * 2.0 - 1.0; //[-1, 1]
        let y = Math.random() * 2.0 - 1.0; //[-1, 1]
        return vec2(x, y);
    }
    //Call animate for the first time
    function animate(milisecs){
    window.requestAnimationFrame(animate);

    //Drawing code
    gl.clear(gl.COLOR_BUFFER_BIT);

    gl.useProgram(program);
    const uWeight = gl.getUniformLocation(program, "uWeight");
    gl.uniform1f(uWeight, 0.5 + Math.sin(milisecs/N_VERTICES)/2.0 );
    gl.drawArrays(gl.LINE_LOOP, 0, N_VERTICES);
}
}



loadShadersFromURLS(["shader.vert", "shader.frag"]).then(shaders => setup(shaders));
//setup(loadShadersFromScripts(["shader.vert", "shader.frag"]));