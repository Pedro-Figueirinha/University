import { buildProgramFromSources, loadShadersFromURLS, setupWebGL } from '../../libs/utils.js';
import { vec2, flatten, subtract, dot } from '../../libs/MV.js';

// Buffers: particles before update, particles after update, quad vertices
let inParticlesBuffer, outParticlesBuffer, quadBuffer;

// Particle system constants

// Total number of particles
const MAX_BODIES = 10;
let xScale = 1.5;
var yScale = 0.0;
const N_PARTICLES = 100000;
let maxPLife = 20;
let minPLife = 2;
let shiftPressed = false;
let mouseDown = false;
let velMin = 0.1;
let velMax = 0.2;
let rotation = 0; //alpha 
let cone_width = 2*Math.PI; //beta [0, 2pi]
let drawPoints = true;
let drawField = true;
const pPosition = [];
const limitPosition = [];
const pRadius = [];
let cursorPos = [0.0, 0.0];

let time = undefined;

function main(shaders)
{
    // Generate the canvas element to fill the entire page
    const canvas = document.createElement("canvas");
    document.body.appendChild(canvas);

    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    yScale = xScale*canvas.height/canvas.width;
    /** type {WebGL2RenderingContext} */
    const gl = setupWebGL(canvas, {alpha: true});

    // Initialize GLSL programs    
    const fieldProgram = buildProgramFromSources(gl, shaders["field-render.vert"], shaders["field-render.frag"]);
    const renderProgram = buildProgramFromSources(gl, shaders["particle-render.vert"], shaders["particle-render.frag"]);
    //?
    const updateProgram = buildProgramFromSources(gl, shaders["particle-update.vert"], shaders["particle-update.frag"], ["fPositionOut", "fAgeOut", "fLifeOut", "fVelocityOut"]);

    gl.viewport(0,0,canvas.width, canvas.height);
    gl.clearColor(0.0, 0.0, 0.0, 1.0);

    // Enable Alpha blending
    gl.enable(gl.BLEND);
    gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA); 

    buildQuad();
    //const p = getCursorPosition(canvas)
    buildParticleSystem(N_PARTICLES);

    window.addEventListener("resize", function(event) {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
        yScale = xScale*canvas.height/canvas.width;
        gl.viewport(0,0,canvas.width, canvas.height);
    });

    window.addEventListener("keydown", function(event) {
        switch(event.key) {
            case "PageUp":
                if (shiftPressed){ 
                    velMin += 0.1;
                }
                else{
                    velMax += 0.1;
                }
                break;
            case "PageDown":
                if (shiftPressed){ 
                    velMin -= 0.1;
                }
                else{
                    velMax -= 0.1;
                }
                break;
            case "ArrowUp":
                    cone_width += 0.1;
                    rotation -= 0.05; // allows to keep direction of particles
                break;
            case "ArrowDown":
                    cone_width -= 0.1;
                    rotation += 0.05; // allows to keep direction of particles
                    break;
            case "ArrowLeft":
                rotation += 0.1;
                break;
            case "ArrowRight":
                rotation -= 0.1;
                break;
            case 'q':
                if(minPLife < maxPLife && minPLife < 19 )
                    minPLife += 1;                
                break;
            case 'a':
                if( minPLife > 1 ){
                    minPLife -= 1;
                }
                break;
            case 'w':
                if(maxPLife < 20){
                    maxPLife += 1;
                }
                break;
            case 's':
                if(maxPLife > minPLife && maxPLife > 2){
                    maxPLife -= 1;
                }
                break;
            case '0':
                drawField = !drawField;
                break;
            case '9':
                drawPoints  = !drawPoints;
                break; 
            case 'Shift':
                shiftPressed = !shiftPressed;
                break;
        }
    });
    function getDistance(a, b){
        //?
        return Math.sqrt( Math.pow((b[0]-a[0]), 2) + Math.pow((b[1]-a[1]), 2) );
    }
    
    canvas.addEventListener("mousedown", function(event) {
        mouseDown = true;
        const centerPosition = getCursorPosition(canvas,event);
        
        pPosition[pPosition.length] = centerPosition;
        pRadius.push(0.0);
    });
    
    canvas.addEventListener("mousemove", function(event) {
        if (shiftPressed){
            cursorPos = getCursorPosition(canvas, event);              
        }
        const endPosition = getCursorPosition(canvas,event);
        if (mouseDown && pPosition.length <= 10){
            const indexCurrPlanet = pPosition.length - 1;
            const centerPosition = pPosition[indexCurrPlanet];
            const currPosition = getCursorPosition(canvas, event);
            limitPosition[indexCurrPlanet] = currPosition;
            let radius = Math.sqrt( Math.pow((endPosition[0] - centerPosition[0]), 2) + Math.pow((endPosition[1] - centerPosition[1]), 2) );
            pRadius[indexCurrPlanet] = radius;
        }     
    });

    canvas.addEventListener("mouseup", function(event) {
        mouseDown = false;
        if(pPosition.length <= 10){

            //calculate radius and push to pRadius array 
            const indexCurrPlanet = pPosition.length - 1;
            const cursorPos = getCursorPosition(canvas, event);        
            const center = pPosition[indexCurrPlanet];
            const radius = getDistance(center, cursorPos); //?
            pRadius[indexCurrPlanet] = radius;
        }    
    })

    
    function getCursorPosition(canvas, event) {
        const mx = event.offsetX;
        const my = event.offsetY;

        const x = ((mx / canvas.width * 2) - 1) * xScale;
        const y = (((canvas.height - my)/canvas.height * 2) -1) * yScale;

        return vec2(x,y);
    }

    window.requestAnimationFrame(animate);

    function buildQuad() {
        const vertices = [-1.0, 1.0, -1.0, -1.0, 1.0, -1.0,
                          -1.0, 1.0,  1.0, -1.0, 1.0,  1.0];
        
        quadBuffer = gl.createBuffer();
        gl.bindBuffer(gl.ARRAY_BUFFER, quadBuffer);
        gl.bufferData(gl.ARRAY_BUFFER, flatten(vertices), gl.STATIC_DRAW);

    }

    function getRandomInt(min, max) {
        min = Math.ceil(min);
        max = Math.floor(max);
        return Math.floor(Math.random()*(max - min + 1)) + min;
    }

    function buildParticleSystem(nParticles) {
        const data = [];
        for(let i=0; i<nParticles; ++i) {
            // position            
            const x = Math.random()*5 -1.5;
            const y = Math.random()*canvas.height -1.5;            

            data.push(x);
            data.push(y);
            
            // age
            data.push(0.0);

            // life 
            gl.useProgram(updateProgram);
            const uTvMax = gl.getUniformLocation(updateProgram,"uTvMax");
            const uTvMin = gl.getUniformLocation(updateProgram, "uTvMin");
            const uRotation = gl.getUniformLocation(updateProgram, "uRotation");
            const uConeWidth = gl.getUniformLocation(updateProgram, "uConeWidth")
            gl.uniform1f(uRotation, rotation);
            gl.uniform1f(uTvMin, minPLife);
            gl.uniform1f(uTvMax, maxPLife);
            gl.uniform1f(uConeWidth, cone_width);    
            const life = getRandomInt(minPLife, maxPLife);
            data.push(life);
            
            // velocity
            gl.useProgram(updateProgram);
            const uVmin = gl.getUniformLocation(updateProgram, "uVmin");
            const uVmax = gl.getUniformLocation(updateProgram, "uVmax");
            let angle = 2 * Math.PI * Math.random()/N_PARTICLES;
            gl.uniform1f(uVmin, velMin * Math.cos(angle) );
            gl.uniform1f(uVmax, velMax * Math.sin(angle) );
            data.push(0.3*(Math.random()-0.5));
            data.push(0.1*(Math.random()-0.5));
        }

        inParticlesBuffer = gl.createBuffer();
        outParticlesBuffer = gl.createBuffer();

        // Input buffer
        gl.bindBuffer(gl.ARRAY_BUFFER, inParticlesBuffer);
        gl.bufferData(gl.ARRAY_BUFFER, flatten(data), gl.STREAM_DRAW);

        // Output buffer
        gl.bindBuffer(gl.ARRAY_BUFFER, outParticlesBuffer);
        gl.bufferData(gl.ARRAY_BUFFER, flatten(data), gl.STREAM_DRAW);
    }

    

    function animate(timestamp)
    {
        let deltaTime = 0;

        if(time === undefined) {        // First time
            time = timestamp/1000;
            deltaTime = 0;
        } 
        else {                          // All other times
            deltaTime = timestamp/1000 - time;
            time = timestamp/1000;
        }

        window.requestAnimationFrame(animate);

        // Clear framebuffer
        gl.clear(gl.COLOR_BUFFER_BIT);

        if(drawField) drawQuad();
        
        updateParticles(deltaTime);
        
        if(drawPoints) drawParticles(outParticlesBuffer, N_PARTICLES);
        
        swapParticlesBuffers();
        
    }
    function updateParticles(deltaTime)
    {
        gl.useProgram(updateProgram);
        for(let i=0; i<pPosition.length; i++) {
            // Get the location of the uniforms...
            const uPosition = gl.getUniformLocation(updateProgram, "uPosition[" + i + "]");
            const uRadius = gl.getUniformLocation(updateProgram, "uRadius[" + i + "]");
            const uPlanetsCounter = gl.getUniformLocation(updateProgram, "uPlanetsCounter");
            // Send the corresponding values to the GLSL program
            gl.uniform2fv(uPosition, pPosition[i]);
            gl.uniform1f(uRadius, pRadius[i]);
            gl.uniform1i(uPlanetsCounter, pPosition.length);
            }

        // Setup uniforms
        const uDeltaTime = gl.getUniformLocation(updateProgram, "uDeltaTime");     
        gl.uniform1f(uDeltaTime, deltaTime);
        const uOrigin = gl.getUniformLocation(updateProgram, "uOrigin");
        gl.uniform2f(uOrigin, cursorPos[0] , cursorPos[1] );
        const uTvMin = gl.getUniformLocation(updateProgram, "uTvMin");
        const uTvMax = gl.getUniformLocation(updateProgram, "uTvMax");
        const uVmin = gl.getUniformLocation(updateProgram, "uVmin");
        const uVmax = gl.getUniformLocation(updateProgram, "uVmax");
        const uRotation = gl.getUniformLocation(updateProgram, "uRotation");
        const uConeWidth = gl.getUniformLocation(updateProgram, "uConeWidth");
        
        gl.uniform1f(uTvMin, minPLife);
        gl.uniform1f(uTvMax, maxPLife);
        gl.uniform1f(uVmin, velMin);
        gl.uniform1f(uVmax, velMax);
        gl.uniform1f(uRotation, rotation);
        gl.uniform1f(uConeWidth, cone_width);

        // Setup attributes
        const vPosition = gl.getAttribLocation(updateProgram, "vPosition");
        const vAge = gl.getAttribLocation(updateProgram, "vAge");
        const vLife = gl.getAttribLocation(updateProgram, "vLife");
        const vVelocity = gl.getAttribLocation(updateProgram, "vVelocity");
        
        
        gl.bindBuffer(gl.ARRAY_BUFFER, inParticlesBuffer);
        
        gl.vertexAttribPointer(vPosition, 2, gl.FLOAT, false, 24, 0);
        gl.vertexAttribPointer(vAge, 1, gl.FLOAT, false, 24, 8);
        gl.vertexAttribPointer(vLife, 1, gl.FLOAT, false, 24, 12);
        gl.vertexAttribPointer(vVelocity, 2, gl.FLOAT, false, 24, 16);
        
        
        gl.enableVertexAttribArray(vPosition);
        gl.enableVertexAttribArray(vAge);
        gl.enableVertexAttribArray(vLife);
        gl.enableVertexAttribArray(vVelocity);

        gl.bindBufferBase(gl.TRANSFORM_FEEDBACK_BUFFER, 0, outParticlesBuffer);
        gl.enable(gl.RASTERIZER_DISCARD);
        gl.beginTransformFeedback(gl.POINTS);
        gl.drawArrays(gl.POINTS, 0, N_PARTICLES);
        gl.endTransformFeedback();
        gl.disable(gl.RASTERIZER_DISCARD);
        gl.bindBufferBase(gl.TRANSFORM_FEEDBACK_BUFFER, 0, null);
        
    }

    function swapParticlesBuffers()
    {
        let auxBuffer = inParticlesBuffer;
        inParticlesBuffer = outParticlesBuffer;
        outParticlesBuffer = auxBuffer;
    }

    function drawQuad() {

        gl.useProgram(fieldProgram);

        // Setup attributes
        const uScale = gl.getUniformLocation(fieldProgram, "uScale");
        gl.uniform2fv(uScale, [xScale, yScale]);
        // Send the bodies' positions
        for(let i=0; i<pPosition.length; i++) {
            // Get the location of the uniforms...
            const uPosition = gl.getUniformLocation(fieldProgram, "uPosition[" + i + "]");
            const uRadius = gl.getUniformLocation(fieldProgram, "uRadius[" + i + "]");
            const uPlanetsCounter = gl.getUniformLocation(fieldProgram, "uPlanetsCounter");
            // Send the corresponding values to the GLSL program
            gl.uniform2fv(uPosition, pPosition[i]);
            gl.uniform1f(uRadius, pRadius[i]);
            gl.uniform1i(uPlanetsCounter, pPosition.length);
            }

        const vPosition = gl.getAttribLocation(fieldProgram, "vPosition"); 

        gl.bindBuffer(gl.ARRAY_BUFFER, quadBuffer);
        gl.enableVertexAttribArray(vPosition);
        gl.vertexAttribPointer(vPosition, 2, gl.FLOAT, false, 0, 0);
        
        gl.drawArrays(gl.TRIANGLES, 0, 6);
    }

    function drawParticles(buffer, nParticles)
    {

        gl.useProgram(renderProgram);

        // Setup attributes
        const vPosition = gl.getAttribLocation(renderProgram, "vPosition");
        const uScale = gl.getUniformLocation(renderProgram, "uScale");
        gl.uniform2fv(uScale, [xScale, yScale]);
        gl.bindBuffer(gl.ARRAY_BUFFER, buffer);

        gl.vertexAttribPointer(vPosition, 2, gl.FLOAT, false, 24, 0);
        gl.enableVertexAttribArray(vPosition);

        gl.drawArrays(gl.POINTS, 0, nParticles);
    }
}


loadShadersFromURLS([
    "field-render.vert", "field-render.frag",
    "particle-update.vert", "particle-update.frag", 
    "particle-render.vert", "particle-render.frag"
    ]
).then(shaders=>main(shaders));