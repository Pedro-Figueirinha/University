import { loadShadersFromURLS, setupWebGL, buildProgramFromSources } from '../../libs/utils.js';
import { mat4, vec3, flatten, lookAt, ortho, mult, translate, rotate, rotateX } from '../../libs/MV.js';

import * as SPHERE from './js/sphere.js';
import * as CUBE from './js/cube.js';

/** @type {WebGLRenderingContext} */
let gl;

let program;

/** View and Projection matrices */
let mView;
let mProjection;

const edge = 2.0;
const CUBESTRING = "Cube";
const SPHERESTRING = "Sphere";

let instances = [];
let transformations = [];
let selectedIndex;

const addBtns = document.getElementById("add_object");
const addCubeBtn = addBtns.querySelector("#add_cube");
const addSphereBtn = addBtns.querySelector("#add_sphere");
const removeBtn = addBtns.querySelector("#remove_object");
var objects = document.getElementById("object_instances");
let transformContainer = document.querySelector("#transform_container");

function addingNewObject(object_type){
    instances.push(object_type);
    var option = document.createElement("option");
    option.text = object_type.concat(instances.length);
    option.selected = true;
    objects.add(option);
    transformations.push(0.0,0.0,0.0,  1.0,1.0,1.0,  0.0,0.0,0.0);
    let selectedIndex =  objects.selectedIndex;
    let startIndex = selectedIndex * 9;
    let currIndex = startIndex;
    var inputs = transformContainer.querySelectorAll("input");
    //update inputs in container with transformation values
    inputs.forEach(input =>{
        console.log(transformations[currIndex]);
        input.value = transformations[currIndex];
        currIndex++;
    });
}

function render(time)
{
    window.requestAnimationFrame(render);

    gl.clear(gl.COLOR_BUFFER_BIT);

    gl.useProgram(program);

    const uCtm = gl.getUniformLocation(program, "uCtm");
    if (instances.length != 0){
        instances.forEach(element => {
            /*let elemIndex = instances.indexOf(element);
            
            let selectedIndex =  objects.selectedIndex;
            let startIndex = selectedIndex * 9;
            let endIndex = startIndex + 9;
            let currIndex = startIndex;
            var inputs = transformContainer.querySelectorAll("input");
            //update inputs in container with transformation values
            inputs.forEach(input =>{
                input.value = transformations[currIndex];
                currIndex++;
            });
            //update transformations array with current inputs values of container
            let inputsIndex = 0;
            for(let i = startIndex; i < endIndex; i++){
                transformations[i] = inputs[inputsIndex].value;
                inputsIndex++;
            }*/

            if(element == CUBESTRING){
                gl.uniformMatrix4fv(uCtm, false, flatten(mult(mProjection, mult(mView, translate(0,2,0)))));
                gl.uniformMatrix4fv(uCtm, false, flatten(mult(mProjection, mult(mView, rotateX(45)))));
                CUBE.draw(gl, program, gl.LINES);
            }
            else if(element == SPHERESTRING){
                gl.uniformMatrix4fv(uCtm, false, flatten(mult(mProjection, mult(mView, translate(0,0,0)))));
                SPHERE.draw(gl, program, gl.LINES);
            }
        });
    }   
    //selecionar de lado para mover o objecto criado
}



function setup(shaders)
{
    const canvas = document.getElementById('gl-canvas');

    canvas.width = canvas.parentElement.clientWidth;
    canvas.height = window.innerHeight;

    gl = setupWebGL(canvas);
    program = buildProgramFromSources(gl, shaders['shader.vert'], shaders['shader.frag']);

    gl.clearColor(0.1, 0.1, 0.1, 1.0);
    gl.viewport(0,0,canvas.width, canvas.height);

    mView = lookAt(vec3(0,0,0), vec3(-1,-1,-2), vec3(0,1,0));
    setupProjection();

    
    

    function setupProjection()
    {
        if(canvas.width < canvas.height) {
            const yLim = edge*canvas.height/canvas.width;
            mProjection = ortho(-edge, edge, -yLim, yLim, -10, 10);
        }
        else {
            const xLim = edge*canvas.width/canvas.height;
            mProjection = ortho(-xLim, xLim, -edge, edge, -10, 10);
        }
    }
    window.addEventListener("resize", function() {
        canvas.width = canvas.parentElement.clientWidth;
        canvas.height = window.innerHeight;

        setupProjection();
    
        gl.viewport(0,0,canvas.width, canvas.height);
    });
    addCubeBtn.addEventListener("click", () =>{
        CUBE.init(gl);
        addingNewObject(CUBESTRING)    

    });
    addSphereBtn.addEventListener("click", () => {
        SPHERE.init(gl);
        addingNewObject(SPHERESTRING);
    });
    removeBtn.addEventListener("click", () =>{
    });
    window.requestAnimationFrame(render);
}

const shaderUrls = ['shader.vert', 'shader.frag'];

loadShadersFromURLS(shaderUrls).then(shaders=>setup(shaders));