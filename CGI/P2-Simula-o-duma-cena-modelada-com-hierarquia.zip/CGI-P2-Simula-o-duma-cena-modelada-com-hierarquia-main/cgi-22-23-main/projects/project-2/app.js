import { buildProgramFromSources, loadShadersFromURLS, setupWebGL } from "../../libs/utils.js";
import { ortho, lookAt, flatten, vec3, rotateX, rotateY, translate } from "../../libs/MV.js";
import { modelView, loadMatrix, multRotationY, multScale, multTranslation, popMatrix, pushMatrix, multMatrix, multRotationX, multRotationZ } from "../../libs/stack.js";

import * as SPHERE from '../../libs/objects/sphere.js';
import * as CUBE from '../../libs/objects/cube.js';
import * as CYLINDER from '../../libs/objects/cylinder.js';
import * as PYRAMID from '../../libs/objects/pyramid.js';
import { GUI } from '../../libs/dat.gui.module.js';
/** @type WebGLRenderingContext */
let gl;

let time = 0;           // Global simulation time in days
let speed = 1 / 60.0;     // Speed (how many days added to time on each render pass
let mode;               // Drawing mode (gl.LINES or gl.TRIANGLES)
let animation = true;   // Animation is running
const VP_DISTANCE = 50;
let spacePressed = false;

//CHOPPER
let moving = false;
const maxHeight = 30;
let flying = false;
let bladeVel = 1000;
let chopperVel = 100;
let inclination = 0;
let chopperScale = 1;
let choperX = 40;
let Chopperheight = 1;
let choperZ = 0;

//CRATE
let maxCrates = 50;
let CrateCoords = [maxCrates * 3];
let CLifes = Array(maxCrates).fill(0);
let angles = [maxCrates];
let intervalUpdCratLif;
let intervalUpdCratHeight;
let crateDim = 5;
let dropcount = 0;

//ENVIRONMENT COMPONENTS
let borderGrassScale = 5;
let groundScale = 100;
let grassScale = 2.5;
let ZapplingDropCountSpawn = 50;
let YoungTreeDropCountSpawn = 100 ;
let FullGrownTreeDropCountSpawn = 150;

//Colors
let blue = vec3(0, 0, 1.0);
let yellow = vec3(1.0, 1.0, 0);
let red = vec3(1.0, 0, 0);
let green = vec3(0, 1.0, 0);
let crateColor = vec3(100 / 255, 64.7 / 255, 0);
let groundColor = vec3(107 / 255, 156 / 255, 88 / 255);
let OuterGrassColor = vec3(0, 128 / 255, 0);
let InnerGrassColor = vec3(0, 110 / 255, 0);
let ForestClearingColor = vec3(139 / 255, 69 / 255, 19 / 255);
let ZapplingColor1 = vec3(93 / 255, 70 / 255, 50 / 255);
let BranchColor1 = vec3(150 / 255, 90 / 255, 50 / 255);

function setup(shaders) {
    let canvas = document.getElementById("gl-canvas");
    let aspect = canvas.width / canvas.height;

    gl = setupWebGL(canvas);

    let program = buildProgramFromSources(gl, shaders["shader.vert"], shaders["shader.frag"]);

    let mProjection = ortho(-VP_DISTANCE * aspect, VP_DISTANCE * aspect, -VP_DISTANCE, VP_DISTANCE, -3 * VP_DISTANCE, 3 * VP_DISTANCE);

    //camera default eye at up
    let camera = {
        eye: vec3(-1, 1, 1),
        at: vec3(0, 0, 0),
        up: vec3(0, 1, 0)
    }
    let mView = lookAt(camera.eye, camera.at, camera.up);

    mode = gl.TRIANGLES;

    resize_canvas();

    let options = {

        gamma: 0,
        theta: 0,

        reset: function () {
            camera.eye[0] = -1;
            camera.eye[1] = 1;
            mView = lookAt(camera.eye, camera.at, camera.up);
        }
    };

    const gui = new GUI();

    const cam = gui.addFolder('Camera');
    //gamma slider
    let sliderGamma = cam.add(options, 'gamma', 0, Math.PI * 2);
    //theta slider
    let sliderTheta = cam.add(options, 'theta', 0, Math.PI * 2);
    cam.open();

    
    const reset = gui.addFolder("Reset view");
    //reset view button
    reset.add(options, 'reset');
    reset.open();

    //updates mview according to the slider's gamma value
    sliderGamma.onChange(function (value) {
        // gamma = value;
        camera.eye[0] = value;
        mView = lookAt(camera.eye, camera.at, camera.up);
    })
     //updates mview according to the slider's theta value
    sliderTheta.onChange(function (value) {
        camera.eye[1] = value;
        mView = lookAt(camera.eye, camera.at, camera.up);

    })



    window.addEventListener("resize", resize_canvas);
    //EVENTS
    document.onkeydown = function (event) {
        switch (event.key) {
            case '1':
                // projeção axonométrica
                mView = lookAt(camera.eye, camera.at, camera.up);
                break;
            case '2':
                // Front view
                mView = lookAt([1, 1, 0], [0, 0, 0], [0, 1, 0]);
                break;
            case '3':
                // Top view
                mView = lookAt([0, 2, 0], [0, 1, 0], [0, 0, -1]);
                break;
            case '4':
                // Right view
                mView = lookAt([1, 1, 0], [0, 1, 0], [0, 1, 0]);
                break;
            case 'ArrowUp':
                if (Chopperheight < maxHeight) { Chopperheight += 0.5; }
                if (!flying) { flying = true; }
                break;
            case 'ArrowDown':
                if (Chopperheight == 1) {
                    flying = false;
                }
                else {
                    Chopperheight -= 0.5;
                }
                break;
            case 'ArrowLeft':
                if (flying) {
                    moving = true;
                }
                break;
            case 'w':
                mode = gl.LINES;
                break;
            case 's':
                mode = gl.TRIANGLES;
                break;
            case ' ':
                if (flying) {
                    spacePressed = true;
                    console.log(spacePressed);
                    for (let i = 0; i < maxCrates; i++) {
                        if (CLifes[i] == 0) {
                            CrateCoords[i * 3] = choperX;
                            CrateCoords[i * 3 + 1] = Chopperheight;
                            CrateCoords[i * 3 + 2] = choperZ;
                            CLifes[i] = 5;
                            angles[i] = chopperVel;
                            dropcount++;
                            break;
                        }
                    }
                }
                break;
            default:
                break;
        }
    }
    document.onkeyup = function (event) {
        switch (event.key) {
            case 'ArrowLeft':
                moving = false;
                break;
            case ' ':
                spacePressed = false;
                break;
        }
    }
    //TIME INTERVAL UPDATES
    function updateCratesLifes() {
        for (let i = 0; i < maxCrates; i++) {
            if (CLifes[i] > 0) { CLifes[i] -= 1; }
        }
    }
    function updateCratesHeights() {
        for (let i = 1; i < maxCrates * 3; i += 3) {
            if (CrateCoords[i] >= crateDim) { CrateCoords[i] -= 0.1; }
        }
    }

    gl.clearColor(135 / 255, 206 / 255, 235 / 255, 1.0);
    SPHERE.init(gl);
    CUBE.init(gl);
    CYLINDER.init(gl);
    PYRAMID.init(gl);

    gl.enable(gl.DEPTH_TEST);   // Enables Z-buffer depth test

    window.requestAnimationFrame(render);


    function resize_canvas(event) {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;

        aspect = canvas.width / canvas.height;

        gl.viewport(0, 0, canvas.width, canvas.height);
        mProjection = ortho(-VP_DISTANCE * aspect, VP_DISTANCE * aspect, -VP_DISTANCE, VP_DISTANCE, -3 * VP_DISTANCE, 3 * VP_DISTANCE);
    }

    function uploadModelView() {
        gl.uniformMatrix4fv(gl.getUniformLocation(program, "mModelView"), false, flatten(modelView()));
    }
    function Helicopter() {
        gl.useProgram(program);
        pushMatrix();
        multRotationY(-50);
        Body();
        popMatrix();
        pushMatrix();
        multRotationY(-50);
        MainRotor();
        popMatrix();
        pushMatrix();
        multRotationY(-50);
        TailRotor();
        popMatrix();
        pushMatrix();
        multRotationY(-50);
        LandingSkid();
        popMatrix();
    }
    function Ground() {
        gl.useProgram(program);
        const uColor = gl.getUniformLocation(program, "uColor");
        gl.uniform3fv(uColor, groundColor);
        multTranslation([0, 0, 0]);
        multScale([groundScale, 1, groundScale]);
        uploadModelView();
        CUBE.draw(gl, program, mode);
    }
    function BorderWall(x, z) {
        for (let i = x; i > -x; i -= 6) {
            pushMatrix();
            multTranslation([i, 4.1, z]);
            multScale([borderGrassScale, borderGrassScale, borderGrassScale]);
            Grass();
            popMatrix();
        }
    }
    //Tall Grass border composed of 4 Border walls
    function Border() {
        pushMatrix();
        //TopLeft
        BorderWall(45, -48)
        popMatrix();
        pushMatrix();
        //Bottom Right
        BorderWall(45, 48)
        popMatrix();
        pushMatrix();
        //Bottom Right
        multRotationY(90);
        BorderWall(48, -48);
        popMatrix();
        pushMatrix();
        //Bottom Right
        multRotationY(-90);
        BorderWall(48, -48);
        popMatrix();
    }
    //Pieces of grass spread over the ground
    function GrassBlocks() {
        pushMatrix();
        multTranslation([25, 4, 20]);
        multRotationY(90);
        multScale([grassScale, grassScale, grassScale]);
        Grass();
        popMatrix();
        pushMatrix();
        multTranslation([-30, 4, 0]);
        multRotationY(90);
        multScale([grassScale, grassScale, grassScale]);
        Grass();
        popMatrix();
        pushMatrix();
        multTranslation([15, 4, -35]);
        multRotationY(0);
        multScale([grassScale, grassScale, grassScale]);
        Grass();
        popMatrix();
        pushMatrix();
        multTranslation([-30, 4, -35]);
        multRotationY(45);
        multScale([grassScale, grassScale, grassScale]);
        Grass();
        popMatrix();
        pushMatrix();
        multTranslation([-15, 4, 35]);
        multRotationY(-45);
        multScale([grassScale, grassScale, grassScale]);
        Grass();
        popMatrix();
        pushMatrix();
        multTranslation([40, 4, -15]);
        multRotationY(45);
        multScale([grassScale, grassScale, grassScale]);
        Grass();
        popMatrix();
    }
    function ForestClearing() {
        //centerbigsize
        pushMatrix();
        gl.useProgram(program);
        const uColor = gl.getUniformLocation(program, "uColor");
        gl.uniform3fv(uColor, ForestClearingColor);
        multScale([40, 1, 40]);
        multTranslation([0, 0.1, 0]);
        uploadModelView();
        CYLINDER.draw(gl, program, mode);
        popMatrix();
        //topleftmidsize
        pushMatrix();
        multTranslation([-10, 2, -10]);
        multRotationY(-30);
        multScale([20, 1, 30]);
        uploadModelView();
        CYLINDER.draw(gl, program, mode);
        popMatrix();
        //toprightmidsize
        pushMatrix();
        multTranslation([6, 2, -11]);
        multRotationY(50);
        multScale([20, 1, 30]);
        uploadModelView();
        CYLINDER.draw(gl, program, mode);
        popMatrix();
        //bottommidsize
        pushMatrix();
        multTranslation([5, 2, 12]);
        multRotationY(0);
        multScale([20, 1, 20]);
        uploadModelView();
        CYLINDER.draw(gl, program, mode);
        popMatrix();
    }
    function Zappling() {
        gl.useProgram(program);
        const uColor = gl.getUniformLocation(program, "uColor");
        gl.uniform3fv(uColor, ZapplingColor1);
        pushMatrix();
        multScale([1, 10, 1]);
        multTranslation([0, 1, 0]);
        uploadModelView();
        CUBE.draw(gl, program, mode);
        popMatrix();
        pushMatrix();
        multTranslation([0, 15, 3.2]);
        multRotationX(45);
        multScale([1, 10, 1]);
        uploadModelView();
        CUBE.draw(gl, program, mode);
        popMatrix();
        pushMatrix();
        multTranslation([0, 18.1, -3.5]);
        multRotationX(-45);
        multScale([1, 10, 1]);
        uploadModelView();
        CUBE.draw(gl, program, mode);
        popMatrix();
        pushMatrix();
        multTranslation([0, 21, -3.5]);
        multRotationX(30);
        multScale([1, 5, 1]);
        uploadModelView();
        CUBE.draw(gl, program, mode);
        popMatrix();
        //small top leaf
        pushMatrix();
        gl.uniform3fv(uColor, InnerGrassColor);
        multTranslation([0, 24.9, -1.5]);
        multRotationX(30);
        multRotationY(90);
        multScale([1, 5, 3]);
        uploadModelView();
        SPHERE.draw(gl, program, mode);
        popMatrix();
        //small middle leaf
        pushMatrix();
        gl.uniform3fv(uColor, InnerGrassColor);
        multTranslation([0, 22.9, -7]);
        multRotationX(-30);
        multRotationY(0);
        multScale([1, 5, 3]);
        uploadModelView();
        SPHERE.draw(gl, program, mode);
        popMatrix();
        //small bottom leaf 1
        pushMatrix();
        gl.uniform3fv(uColor, InnerGrassColor);
        multTranslation([0, 20, 6]);
        multRotationX(-30);
        multRotationY(90);
        multScale([1, 5, 3]);
        uploadModelView();
        SPHERE.draw(gl, program, mode);
        popMatrix();
        //small bottom leaf 2
        pushMatrix();
        gl.uniform3fv(uColor, InnerGrassColor);
        multTranslation([0, 19.5, 7.5]);
        multRotationX(30);
        multRotationY(45);
        multScale([1, 5, 3]);
        uploadModelView();
        SPHERE.draw(gl, program, mode);
        popMatrix();


    }
    function Trunk() {
        gl.useProgram(program);
        const uColor = gl.getUniformLocation(program, "uColor");
        gl.uniform3fv(uColor, ZapplingColor1);
        pushMatrix();
        multScale([5, 20, 5]);
        multTranslation([0, 1, 0]);
        uploadModelView();
        CUBE.draw(gl, program, mode);
        popMatrix();
    }
    function YngTreeBranches() {
        gl.useProgram(program);
        const uColor = gl.getUniformLocation(program, "uColor");
        //top branch
        gl.uniform3fv(uColor, BranchColor1);
        pushMatrix();
        multTranslation([-3, 32, 1]);
        multRotationX(0);
        multRotationZ(30)
        multScale([2, 10, 2]);
        uploadModelView();
        CUBE.draw(gl, program, mode);
        popMatrix();
        //mid branch
        gl.uniform3fv(uColor, BranchColor1);
        pushMatrix();
        multTranslation([1, 20, 4]);
        multRotationX(30);
        multRotationZ(-20)
        multScale([2, 10, 2]);
        uploadModelView();
        CUBE.draw(gl, program, mode);
        popMatrix();
        //top right branch
        gl.uniform3fv(uColor, BranchColor1);
        pushMatrix();
        multTranslation([-1.4, 20, -3]);
        multRotationX(-30);
        multRotationZ(40)
        multScale([2, 10, 2]);
        uploadModelView();
        CUBE.draw(gl, program, mode);
        popMatrix();
    }
    function YngTreeLeaf() {
        gl.useProgram(program);
        pushMatrix();
        multTranslation([0, 19.5, 7.5]);
        multRotationX(30);
        multRotationY(45);
        multScale([1, 5, 3]);
        uploadModelView();
        SPHERE.draw(gl, program, mode);
        popMatrix();
        pushMatrix();
        multTranslation([0, 19.5, 7.5]);
        multRotationX(90);
        multRotationY(0);
        multScale([1, 5, 3]);
        uploadModelView();
        SPHERE.draw(gl, program, mode);
        popMatrix();
        pushMatrix();
        multTranslation([0, 20.5, 7.5]);
        multRotationX(20);
        multRotationY(0);
        multScale([1, 5, 3]);
        uploadModelView();
        SPHERE.draw(gl, program, mode);
        popMatrix();
    }
    function YngTreeLeafs() {
        gl.useProgram(program)
        const uColor = gl.getUniformLocation(program, "uColor");
        gl.uniform3fv(uColor, InnerGrassColor);
        pushMatrix();
        multTranslation([3, 6, 0]);
        YngTreeLeaf();
        popMatrix();
        pushMatrix();
        multScale([0.5, 0.5, 0.5]);
        multTranslation([-11, 20, -10]);
        multRotationY(45);
        YngTreeLeaf();
        popMatrix();
        pushMatrix();
        multScale([0.5, 0.5, 0.5]);
        multTranslation([-5, 20, 5]);
        multRotationY(45);
        YngTreeLeaf();
        popMatrix();
        pushMatrix();
        multTranslation([-12, 5, -5]);
        multRotationY(90);
        YngTreeLeaf();
        popMatrix();
        pushMatrix();
        multTranslation([-12, 18, -4]);
        multRotationY(45);
        YngTreeLeaf();
        popMatrix();
        pushMatrix();
        multTranslation([-3, 7, -8]);
        multRotationY(45);
        YngTreeLeaf();
        popMatrix();
        pushMatrix();
        multTranslation([-2, 10, -3]);
        multRotationY(45);
        YngTreeLeaf();
        popMatrix();
    }

    function YoungTree() {
        pushMatrix();
        Trunk();
        popMatrix();
        pushMatrix();
        YngTreeBranches();
        popMatrix();
        pushMatrix();
        YngTreeLeafs();
        popMatrix();

    }
    function tinyLeafs() {
        gl.useProgram(program);
        const uColor = gl.getUniformLocation(program, "uColor");
        gl.uniform3fv(uColor, InnerGrassColor);
        //base
        pushMatrix();
        multTranslation([0, -20, 12]);
        YngTreeLeaf();
        popMatrix();

        pushMatrix();
        multRotationY(-90);
        multRotationX(30);
        multRotationZ(90);
        multTranslation([-5, -15, 9]);
        YngTreeLeaf();
        popMatrix();
        pushMatrix();
        multRotationY(-50);
        multRotationX(-60);
        multRotationZ(45);
        multTranslation([0, -20, 9]);
        YngTreeLeaf();
        popMatrix();
        pushMatrix();
        multRotationY(40);
        multRotationX(-30);
        multTranslation([0, -20, 12]);
        YngTreeLeaf();
        popMatrix();
        pushMatrix();
        multRotationY(70);
        multRotationX(30);
        multTranslation([0, -20, 12]);
        YngTreeLeaf();
        popMatrix();
        pushMatrix();
        multRotationY(120);
        multRotationX(-10);
        multTranslation([0, -20, 12]);
        YngTreeLeaf();
        popMatrix();
        pushMatrix();
        multRotationY(80);
        multRotationX(0);
        multRotationZ(45);
        multTranslation([0, -20, 12]);
        YngTreeLeaf();
        popMatrix();
        pushMatrix();
        multRotationY(180);
        multRotationX(-20);
        multRotationZ(90);
        multTranslation([0, -20, 12]);
        YngTreeLeaf();
        popMatrix();
        pushMatrix();
        multRotationY(180);
        multRotationX(-20);
        multRotationZ(90);
        multTranslation([0, -20, 12]);
        YngTreeLeaf();
        popMatrix();
        pushMatrix();
        multRotationY(-60);
        multRotationX(-20);
        multRotationZ(-50);
        multTranslation([0, -20, 12]);
        YngTreeLeaf();
        popMatrix();
        pushMatrix();
        multRotationY(-120);
        multRotationX(-5);
        multRotationZ(-50);
        multTranslation([0, -20, 12]);
        YngTreeLeaf();
        popMatrix();
        pushMatrix();
        multRotationY(-40);
        multRotationX(25);
        multRotationZ(-50);
        multTranslation([-0, -20, 10]);
        YngTreeLeaf();
        popMatrix();
        pushMatrix();
        multRotationY(140);
        multRotationX(-70);
        multTranslation([0, -20, 6.5]);
        YngTreeLeaf();
        popMatrix();
    }
    function bigChunkLeaf() {
        gl.useProgram(program);
        pushMatrix();
        multTranslation([0, 0, 0]);
        multScale([40, 30, 40]);
        uploadModelView();
        SPHERE.draw(gl, program, mode);
        popMatrix();
    }
    function GrownTreeLeaf() {
        gl.useProgram(program);
        const uColor = gl.getUniformLocation(program, "uColor");
        gl.uniform3fv(uColor, OuterGrassColor);
        pushMatrix()
        bigChunkLeaf();
        popMatrix();
        pushMatrix();
        tinyLeafs();
        popMatrix();
    }
    function GrownTreeLeafs() {
        pushMatrix();
        //Biggest
        multTranslation([0, 10, 0]);
        GrownTreeLeaf();
        popMatrix();
        pushMatrix();
        //Smallest
        //multScale
        //GrownTreeLeaf();
        popMatrix();
    }
    function FullGrownTree() {
        pushMatrix();
        multScale([1.5, 1.2, 1.5]);
        multTranslation([0, -30, 0]);
        Trunk();
        popMatrix();
        pushMatrix();
        GrownTreeLeafs();
        popMatrix();
    }
    function Environment() {
        gl.useProgram(program);
        pushMatrix();
            Border();
        popMatrix();
        pushMatrix();
            GrassBlocks();
        popMatrix()
        pushMatrix();
            ForestClearing();
        popMatrix();
        //TREE
        if (dropcount >= ZapplingDropCountSpawn && dropcount < YoungTreeDropCountSpawn) {
            pushMatrix();
                Zappling();
            popMatrix();
        }
        else if (dropcount >= YoungTreeDropCountSpawn && dropcount < FullGrownTreeDropCountSpawn) {
            pushMatrix();
                multScale([1.1, 1.3, 1.1]);
                multTranslation([0, -5, 0])
                YoungTree();
            popMatrix();
        }
        else if (dropcount > FullGrownTreeDropCountSpawn) {
            pushMatrix();
                multTranslation([0, 26, 0]);
                FullGrownTree();
            popMatrix();
        }
        uploadModelView();
    }
    function Grass() {
        pushMatrix();
        gl.useProgram(program);
        const uColor = gl.getUniformLocation(program, "uColor");
        gl.uniform3fv(uColor, OuterGrassColor);
        multScale([1.5, 1., 1]);
        multTranslation([-0.7, -0.2, 0.0]);
        uploadModelView();
        PYRAMID.draw(gl, program, mode);
        popMatrix();
        pushMatrix();
        multScale([1.5, 1., 1]);
        multTranslation([0.1, -0.2, 0.0]);
        uploadModelView();
        PYRAMID.draw(gl, program, mode);
        popMatrix();
        pushMatrix();
        gl.uniform3fv(uColor, InnerGrassColor);
        multScale([1, 1.2, 1.1]);
        multTranslation([-0.5, -0.1, 0]);
        uploadModelView();
        PYRAMID.draw(gl, program, mode);
        popMatrix();
    }

    function Crate() {
        gl.useProgram(program);
        const uColor = gl.getUniformLocation(program, "uColor");
        gl.uniform3fv(uColor, crateColor);
        multScale([crateDim, crateDim, crateDim]);
        uploadModelView();
        CUBE.draw(gl, program, mode);
    }
    function Body() {
        gl.useProgram(program);
        const uColor = gl.getUniformLocation(program, "uColor");
        gl.uniform3fv(uColor, red);
        pushMatrix();
            multTranslation([-3.5, 2.2, 0]);
            multScale([7, 3, 3]);
            uploadModelView();
            SPHERE.draw(gl, program, mode);
        popMatrix();
        pushMatrix();
            multTranslation([1.5, 3.2, 0]);
            multScale([8, 1, 1]);
            uploadModelView();
            SPHERE.draw(gl, program, mode);
        popMatrix();

        pushMatrix();
            multTranslation([5.5, 3.7, 0]);
            multRotationZ(45);
            multScale([2, 1, 1]);
            uploadModelView();
            SPHERE.draw(gl, program, mode);
        popMatrix();
    }
    function MainRotor() {
        pushMatrix();
            MRotor();
        popMatrix();
        pushMatrix();
            MainBlade();
        popMatrix();
    }
    function TailRotor() {
        pushMatrix();
            TailBlade();
        popMatrix();
        pushMatrix();
            TRotor();
        popMatrix();
    }

    function MainBlade() {

        gl.useProgram(program);
        const uColor = gl.getUniformLocation(program, "uColor");
        gl.uniform3fv(uColor, blue);
        multTranslation([-3.5, 5.6, 0.1]);
        if (flying) { multRotationY(time * bladeVel); }
        multScale([15, 0.2, 1]);
        uploadModelView();
        SPHERE.draw(gl, program, mode);
    }
    function MRotor() {

        gl.useProgram(program);
        const uColor = gl.getUniformLocation(program, "uColor");
        gl.uniform3fv(uColor, yellow);
        multTranslation([-3.5, 4.5, 0]);
        multScale([0.2, 2.5, 0.2]);
        uploadModelView();
        CYLINDER.draw(gl, program, mode);
    }
    function TailBlade() {
        gl.useProgram(program);
        const uColor = gl.getUniformLocation(program, "uColor");
        gl.uniform3fv(uColor, blue);
        multTranslation([5.7, 4, 0.85]);
        multScale([2, 2, 2]);
        if (flying) { multRotationZ(time * bladeVel); }
        multScale([0.3, 2, 0.05]);
        uploadModelView();
        SPHERE.draw(gl, program, mode);
    }
    function TRotor() {
        gl.useProgram(program);
        const uColor = gl.getUniformLocation(program, "uColor");
        gl.uniform3fv(uColor, yellow);
        multTranslation([5.7, 4.1, 0.6]);
        multScale([0.2, 0.2, .7]);
        uploadModelView();
        CYLINDER.draw(gl, program, mode);
    }
    function LSLeg() {
        gl.useProgram(program);
        const uColor = gl.getUniformLocation(program, "uColor");
        gl.uniform3fv(uColor, yellow);
        multScale([0.3, 1.5, 0.2]);
        uploadModelView();
        CUBE.draw(gl, program, mode);
    }

    function LandingSkid() {
        //back left
        pushMatrix();
        multTranslation([-2, 0.7, 1]);
        multRotationZ(30);
        multRotationX(-15);
        LSLeg();
        popMatrix();
        //back right
        pushMatrix();
        multTranslation([-2, 0.7, -1]);
        multRotationZ(30);
        multRotationX(15);
        LSLeg();
        popMatrix();
        //front left
        pushMatrix();
        multTranslation([-5, 0.7, 1]);
        multRotationZ(-30);
        multRotationX(-15);
        LSLeg();
        popMatrix();
        //front right
        pushMatrix();
        multTranslation([-5, 0.7, -1]);
        multRotationZ(-30);
        multRotationX(15);
        LSLeg();
        popMatrix();


        gl.useProgram(program);
        const uColor = gl.getUniformLocation(program, "uColor");
        gl.uniform3fv(uColor, green);
        //left skid cyl
        pushMatrix();
        multTranslation([-3.5, 0, 1.2]);
        multScale([12, 0.2, 0.2]);
        uploadModelView();
        CYLINDER.draw(gl, program, mode);
        popMatrix();
        //right skid cyl
        pushMatrix();
        multTranslation([-3.5, 0, -1.2]);
        multScale([12, 0.2, 0.2]);
        uploadModelView();
        CYLINDER.draw(gl, program, mode);
        popMatrix();
    }    


    function render() {
        if (animation) {
            time += speed
            if (!intervalUpdCratLif) { intervalUpdCratLif = setInterval(updateCratesLifes, 1000); }
            if (!intervalUpdCratHeight) { intervalUpdCratHeight = setInterval(updateCratesHeights, 1); }
        }
        window.requestAnimationFrame(render);
        gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
        gl.useProgram(program);
        gl.uniformMatrix4fv(gl.getUniformLocation(program, "mProjection"), false, flatten(mProjection));
        //eye, at , up
        loadMatrix(mView);     
        pushMatrix();
            Ground();
        popMatrix();
        pushMatrix();
            Environment();
        popMatrix();
        for (let i = 0; i < maxCrates; i++) {
            if (CLifes[i] != 0) {
                let xCoord = CrateCoords[i * 3];
                let yCoord = CrateCoords[i * 3 + 1];
                let zCoord = CrateCoords[i * 3 + 2];
                pushMatrix();
                    multRotationY(angles[i]);
                    multTranslation([xCoord, yCoord - 2, zCoord]);
                    uploadModelView();
                    Crate();
                popMatrix();
            }
        }
        if (!moving && inclination > 0) {
            inclination--;
        }
        else if (moving && inclination < 30) {
            inclination++;
            chopperVel += 2;
        }
        else if (moving) { chopperVel += 2; }
        pushMatrix();
            multScale([chopperScale, chopperScale, chopperScale]);
            multRotationY(chopperVel);
            multTranslation([choperX, Chopperheight, choperZ]);
            multRotationZ(inclination);
            Helicopter();
        popMatrix();
    }
}

const urls = ["shader.vert", "shader.frag"];
loadShadersFromURLS(urls).then(shaders => setup(shaders))